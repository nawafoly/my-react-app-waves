// scripts/resetOwnerPassword.js
import admin from "firebase-admin";
import fs from "fs";
import path from "path";

// 1) حمّل الـ Service Account
const serviceAccountPath = path.resolve(
  __dirname,
  "../serviceAccount/waves-hotel-dashboard-firebase-adminsdk-xxxxx.json"
);
const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, "utf8"));

// 2) ابتدئ الـ Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// 3) UID الخاص بالـowner وكلمة المرور الجديدة
const OWNER_UID = "OKlF8fNov9QaKuswtTIrE3eRwxA3";
const NEW_PASSWORD = "NewOwner@123";

// 4) نفّذ التحديث
admin
  .auth()
  .updateUser(OWNER_UID, { password: NEW_PASSWORD })
  .then((userRecord) => {
    console.log(
      `✅ تم تغيير كلمة مرور المستخدم (${userRecord.uid}) إلى: ${NEW_PASSWORD}`
    );
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ فشل تحديث كلمة المرور:", error);
    process.exit(1);
  });
