// src/layouts/OwnerLayout.tsx
import React from "react";
import Topbar from "../components/Topbar";
import Sidebar from "../components/Sidebar";
import { Outlet } from "react-router-dom";

const OwnerLayout: React.FC = () => {
  return (
    <div className="owner-layout">
      <Sidebar />
      <div className="owner-main">
        <Topbar />
        <div className="owner-content">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default OwnerLayout;
