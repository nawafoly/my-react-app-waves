import type { Role } from "../types/User";

export function getLandingPath(roleInput: string | Role): string {
    const r = String(roleInput).toLowerCase() as Role;
    switch (r) {
        case "owner":
            return "/owner/dashboard";
        case "supervisor":
            return "/supervisor";
        case "employee":
            return "/employee";
        case "guest":
        default:
            return "/guest/home";
    }
}


