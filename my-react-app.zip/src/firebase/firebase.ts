// src/firebase/firebase.ts
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";

// القيم اللي طلعت لك من Firebase Console (نسخة الويب)
const firebaseConfig = {
  apiKey: "AIzaSyAN-KqJ9EM2BZslJvwGhB1Cc2-CqJfO2lM", // هذا الصح من الConsole
  authDomain: "waves-hotel-dashboard.firebaseapp.com",
  projectId: "waves-hotel-dashboard",
  storageBucket: "waves-hotel-dashboard.appspot.com",
  messagingSenderId: "526258019135",
  appId: "1:526258019135:web:23cef7af35f1508574518a",
  measurementId: "G-K158N8662B",
};


// تأكد ما تنشئ أكثر من تطبيق واحد
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// تصدير الخدمات اللي تستخدمها
export const db = getFirestore(app);
export const auth = getAuth(app);

// Analytics اختياري، تقدر تفعّله إذا حاب وتخلي fallback إذا ما تبي تستخدمه
let analytics: ReturnType<typeof getAnalytics> | null = null;
try {
  analytics = getAnalytics(app);
} catch (e) {
  // لو فيه مشكلة (مثلاً يعمل على localhost بدون إعدادات مناسبة) نتجاهلها
  console.warn("Analytics not initialized:", e);
}
export { analytics };
