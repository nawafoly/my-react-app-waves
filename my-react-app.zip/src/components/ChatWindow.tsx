// src/components/ChatWindow.tsx
import React, { useEffect, useState, useRef } from "react";
import { ChatService, Message } from "../services/ChatService";
import "../styles/Chat.css";

interface ChatWindowProps {
  chatId: string;
  currentUserUid: string;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ chatId, currentUserUid }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribe = ChatService.subscribeToMessages(chatId, msgs => {
      setMessages(msgs);
      bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    });
    return () => unsubscribe();
  }, [chatId]);

  const handleSend = async () => {
    if (!text.trim()) return;
    const res = await ChatService.sendMessage(chatId, currentUserUid, text);
    if (!res.ok) return console.error(res.error);
    setText("");
  };

  return (
    <div className="chat-window">
      <div className="chat-header">دردشة القسم</div>
      <div className="messages">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`message ${msg.senderUid === currentUserUid ? "mine" : "other"}`}
          >
            <span>{msg.text}</span>
            <small>{msg.createdAt.toLocaleTimeString()}</small>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div className="input-area">
        <input
          type="text"
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="اكتب رسالتك..."
        />
        <button onClick={handleSend}>إرسال</button>
      </div>
    </div>
  );
};

export default ChatWindow;  // تأكد من وجود هذا السطر
