import React from "react";

type Option = { label: string; value: string };
type Props = {
  options: Option[];
  value?: string;
  placeholder?: string;
  onChange: (value: string) => void;
  dir?: "rtl" | "ltr";
};

export default function ThemedSelect({ options, value, onChange, placeholder, dir = "rtl" }: Props) {
  const [open, setOpen] = React.useState(false);
  const btnRef = React.useRef<HTMLButtonElement>(null);

  const selected = options.find(o => o.value === value);

  function handleSelect(v: string) {
    onChange(v);
    setOpen(false);
    btnRef.current?.focus();
  }

  React.useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!(e.target as HTMLElement)?.closest?.(".tselect")) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  return (
    <div className="tselect" dir={dir} style={{ position: "relative" }}>
      <button
        type="button"
        ref={btnRef}
        className="tselect-btn"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen(s => !s)}
      >
        <span>{selected?.label || placeholder || "اختر..."}</span>
        <span className="tselect-caret">▾</span>
      </button>

      {open && (
        <div className="tselect-menu" role="listbox">
          {options.map(opt => (
            <div
              key={opt.value}
              role="option"
              aria-selected={opt.value === value}
              className={"tselect-item" + (opt.value === value ? " is-selected" : "")}
              onClick={() => handleSelect(opt.value)}
            >
              {opt.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
