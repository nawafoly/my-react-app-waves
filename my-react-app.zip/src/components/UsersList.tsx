import React, { useEffect, useState } from "react";
import { ChatService } from "../services/ChatService";
import "../styles/Chat.css";

interface User {
  uid: string;
  displayName?: string;
}

interface UsersListProps {
  onStartDirectChat: (otherUid: string) => void;
}

const UsersList: React.FC<UsersListProps> = ({ onStartDirectChat }) => {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    ChatService.getAllUsers().then((res) => {
      if (res.ok) setUsers(res.data);
      else console.error(res.error);
    });
  }, []);

  return (
    <ul className="users-list">
      {users.map((u) => (
        <li key={u.uid} className="user-item">
          <span>{u.displayName || u.uid}</span>
          <button
            className="start-chat-btn"
            onClick={() => onStartDirectChat(u.uid)}
          >
            بدء محادثة
          </button>
        </li>
      ))}
    </ul>
  );
};

export default UsersList;
