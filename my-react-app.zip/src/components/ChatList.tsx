// src/components/ChatList.tsx
import React, { useEffect, useState } from "react";
import { ChatService, ChatRoom } from "../services/ChatService";
import "../styles/Chat.css";
import NewChatModal from "./NewChatModal";
import UsersList from "./UsersList";

// حدد النوع على مستوى الملف، ليس داخل الدالة
type Mode = "department" | "direct" | "global";

interface ChatListProps {
  department: string;
  onSelectChat: (chatId: string) => void;
}

const ChatList: React.FC<ChatListProps> = ({ department, onSelectChat }) => {
  // استخدم الـ generic هنا
  const [mode, setMode] = useState<Mode>("department");
  const [chats, setChats] = useState<ChatRoom[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const currentUid = localStorage.getItem("userUid")!;

  const fetchChats = async () => {
    let list: ChatRoom[] = [];
    if (mode === "global") {
      const res = await ChatService.getAllChats();
      if (res.ok) list = res.data; else return console.error(res.error);
    } else if (mode === "direct") {
      const all = await ChatService.getAllChats();
      if (!all.ok) return console.error(all.error);
      list = all.data.filter(
        (c) =>
          c.participants.length === 2 && c.participants.includes(currentUid)
      );
    } else {
      const res = await ChatService.getChatsForDepartment(department);
      if (res.ok) list = res.data; else return console.error(res.error);
    }
    setChats(list);
  };

  useEffect(() => {
    fetchChats();
  }, [mode, department]);

  const handleCreateChat = async (participants: string[]) => {
    const res = await ChatService.createChat(
      mode === "department" ? department : null,
      participants
    );
    if (!res.ok) return console.error(res.error);
    await fetchChats();
    onSelectChat(res.data);
  };

  return (
    <div className="chat-list">
      {/* تبويبات الوضع */}
      <div className="chat-list-modes">
        <button
          className={mode === "global" ? "active" : ""}
          onClick={() => setMode("global")}
        >
          عام
        </button>
        <button
          className={mode === "direct" ? "active" : ""}
          onClick={() => setMode("direct")}
        >
          ثنائي
        </button>
        <button
          className={mode === "department" ? "active" : ""}
          onClick={() => setMode("department")}
        >
          القسم
        </button>
      </div>

      {/* هيدر القائمة */}
      <div className="chat-list-header">
        <h3>
          {mode === "global"
            ? "الدردشة العامة"
            : mode === "direct"
            ? "دردشات ثنائية"
            : `الدردشات – ${department}`}
        </h3>
        <button className="btn new-chat-button" onClick={() => setModalOpen(true)}>
          إنشاء جديد
        </button>
      </div>

      {/* المحتوى حسب الوضع */}
      {mode === "direct" ? (
        <UsersList
          onStartDirectChat={(otherUid) =>
            handleCreateChat([currentUid, otherUid])
          }
        />
      ) : (
        <ul>
          {chats.map((chat) => (
            <li key={chat.id} onClick={() => onSelectChat(chat.id)}>
              {mode === "global"
                ? "الدردشة العامة"
                : mode === "direct"
                ? `بين ${chat.participants.find((u) => u !== currentUid)}`
                : chat.participants.join("، ")}
            </li>
          ))}
        </ul>
      )}

      {/* مودال الإنشاء */}
<NewChatModal
  mode={mode}                   // مرر الوضع الحالي
  isOpen={modalOpen}
  onClose={() => setModalOpen(false)}
  onCreate={handleCreateChat}
/>
    </div>
  );
};

export default ChatList;
