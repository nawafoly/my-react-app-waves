import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Perm, userHas } from "../services/AuthService";

type Props = {
  children: React.ReactElement;
  requiredPerm?: Perm; // ✅ صلاحية مطلوبة
};

export default function ProtectedRoute({ children, requiredPerm }: Props) {
  const { user, loading } = useAuth();
  const location = useLocation();

  // Show spinner when auth is loading.
  if (loading) {
    console.log('[Guard] Authentication loading...');
    return <div className="spinner"></div>; // Assuming a spinner component or class exists
  }

  // If not authenticated, redirect to /login (preserve current location).
  if (!user) {
    console.log('[Guard] User not authenticated, redirecting to login.');
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // If permission denied, redirect to /unauthorized.
  if (requiredPerm) {
    const hasPermission = userHas(user, requiredPerm);
    console.log('[Guard]', { user, requiredPerm, has: hasPermission });
    if (!hasPermission) {
      console.log(`[Guard] Permission denied for user ${user.id} to access ${requiredPerm}.`);
      return <Navigate to="/unauthorized" replace />;
    }
  }

  return children;
}


