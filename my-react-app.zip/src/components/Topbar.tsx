import React, { useEffect, useRef, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Topbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const name = user?.name || "ضيف";
  const initial = (name?.trim()?.[0] || "؟").toUpperCase();

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("mousedown", onClickOutside);
    return () => window.removeEventListener("mousedown", onClickOutside);
  }, []);

  const handleSignOut = async () => {
    try {
      logout();
      navigate("/login", { replace: true });
    } catch (e) { console.error(e); }
  };

  const toggleTheme = () => {
    const current = document.documentElement.getAttribute("data-theme");
    const next = current === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("theme", next);
  };

  return (
    <header className="topbar">
      <div className="topbar-inner">
        <div className="topbar-userwrap" ref={ref}>
          <button className="topbar-user" onClick={() => setOpen(!open)}>
            <div className="topbar-avatar">{initial}</div>
            <span className="topbar-greet">مرحبًا، <b>{name}</b></span>
            <svg width="16" height="16" viewBox="0 0 20 20" aria-hidden="true">
              <path d="M5 7l5 6 5-6" fill="none" stroke="currentColor" strokeWidth="2"/>
            </svg>
          </button>

          {open && (
            <div className="topbar-menu card">
              <a className="topbar-item" href="/dashboard">لوحة التحكم</a>
              <button className="topbar-item" onClick={toggleTheme}>تبديل الثيم</button>
              <button className="topbar-item danger" onClick={handleSignOut}>تسجيل الخروج</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Topbar;
