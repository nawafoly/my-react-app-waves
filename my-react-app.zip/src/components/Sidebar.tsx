// src/components/Sidebar.tsx
import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import SidebarItem from "./ui/SidebarItem";
import SidebarCard from "./ui/SidebarCard";
import {
  FaHome,
  FaUsers,
  FaChartBar,
  FaCog,
  FaSignOutAlt,
  FaComments,
  FaBell,
  FaCalendarCheck,
} from "react-icons/fa";

import "../styles/Sidebar.css";

const SIDEBAR_KEY = "ui.sidebar.state";

type SidebarState = "expanded" | "medium" | "collapsed";

const Sidebar: React.FC = () => {
  const { logout, user } = useAuth();
  const role = user?.role || "guest";

  const [sidebarState, setSidebarState] = useState<SidebarState>("expanded");

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(SIDEBAR_KEY) as SidebarState;
    if (saved) setSidebarState(saved);
  }, []);

  // Save to localStorage on state change
  useEffect(() => {
    localStorage.setItem(SIDEBAR_KEY, sidebarState);
  }, [sidebarState]);

  const toggleSidebar = () => {
    const next: SidebarState =
      sidebarState === "expanded"
        ? "medium"
        : sidebarState === "medium"
        ? "collapsed"
        : "expanded";
    setSidebarState(next);
  };

  const menuItems = [
    {
      to: "/dashboard",
      icon: <FaHome />,
      label: "Dashboard",
      show: true,
      notify: true,
    },
    { to: "/teams", icon: <FaUsers />, label: "Teams", show: role === "owner" },
    {
      to: "/payments",
      icon: <FaChartBar />,
      label: "Payments",
      show: role === "owner",
    },
    {
      to: "/attendance",
      icon: <FaCalendarCheck />,
      label: "Attendance",
      show: role !== "guest",
    },
    { to: "/settings", icon: <FaCog />, label: "Settings", show: true },
  ];

  return (
    <aside className={`sidebar ${sidebarState}`}>
      <div className="sidebar-inner">
        {/* Brand */}
        <div className="sidebar-brand">
          <div className="brand-icon">
            <span className="brand-dot" />
          </div>
          {sidebarState !== "collapsed" && <h1>Teams.co</h1>}
        </div>

        {/* Profile */}
        {sidebarState === "expanded" && (
          <div className="sidebar-profile">
            <img src="/avatar.png" alt="avatar" className="avatar" />
            <div className="profile-info">
              <div className="name">{user?.name || "Aman"}</div>
              <div className="role">{role}</div>
            </div>
          </div>
        )}

        {/* Menu */}
        <div className="sidebar-menu">
          {menuItems
            .filter((item) => item.show)
            .map((item, index) => (
              <SidebarItem
                key={index}
                to={item.to}
                icon={item.icon}
                label={item.label}
                notify={item.notify}
                state={sidebarState}
              />
            ))}
        </div>

        {/* Medium Mode Stats */}
        {sidebarState === "medium" && (
          <div className="sidebar-stats">
            <div className="stats-title">Statistics</div>
            <div className="stats-grid">
              <div className="tile">Efficiency</div>
              <div className="tile">Progress</div>
            </div>
          </div>
        )}

        {/* CTA Card */}
        {sidebarState !== "collapsed" && <SidebarCard state={sidebarState} />}

        {/* Logout */}
        <div className="sidebar-footer">
          <button className="logout-btn" onClick={logout}>
            <FaSignOutAlt />
            {sidebarState !== "collapsed" && <span>Logout</span>}
          </button>
        </div>

        {/* Toggle Button */}
        <div
          role="button"
          tabIndex={0}
          className="sidebar-toggle"
          onClick={toggleSidebar}
          onKeyDown={(e) => e.key === "Enter" && toggleSidebar()}
        >
          <div className="toggle-dot" />
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
