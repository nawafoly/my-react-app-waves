// src/components/ui/SidebarCard.tsx
import React from "react";
import "../../styles/Sidebar.css";

interface SidebarCardProps {
  state: "expanded" | "medium" | "collapsed";
}

const SidebarCard: React.FC<SidebarCardProps> = ({ state }) => {
  const isExpanded = state === "expanded";
  const isMedium = state === "medium";

  return (
    <div
      className={`sidebar-card ${state}`}
      role="region"
      aria-label="Create Teams CTA"
    >
      <div className="card-header">
        <div className="dots-icon">⋯</div>
      </div>
      <div className="card-content">
        <div className="card-icon">
          {/* يمكنك استبدال هذا بـ SVG فعلي لاحقًا */}
          <img src="/bar-chart.svg" alt="Chart" />
        </div>
        <div className="card-text">
          <h4>Create Teams</h4>
          {isExpanded && <p>Increase your speed with more members</p>}
        </div>
        <button className="card-button">Create Teams</button>
      </div>
    </div>
  );
};

export default SidebarCard;
