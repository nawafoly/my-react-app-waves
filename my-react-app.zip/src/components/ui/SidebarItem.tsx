// src/components/ui/SidebarItem.tsx
import React from "react";
import { NavLink } from "react-router-dom";
import "../../styles/Sidebar.css";

interface SidebarItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  notify?: boolean;
  state: "expanded" | "medium" | "collapsed";
}

const SidebarItem: React.FC<SidebarItemProps> = ({
  to,
  icon,
  label,
  notify,
  state,
}) => {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `sidebar-item ${state} ${isActive ? "active" : ""}`
      }
    >
      <div className="icon-wrapper">
        {icon}
        {notify && <span className="notify-dot" />}
      </div>
      {state !== "collapsed" && <span className="label">{label}</span>}
    </NavLink>
  );
};

export default SidebarItem;
