// src/components/NewChatModal.tsx
import React, { useState } from "react";
import "../styles/Chat.css";

type Mode = "department" | "direct" | "global";

interface NewChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (participants: string[]) => void;
  mode: Mode; // <-- جديد
}

const NewChatModal: React.FC<NewChatModalProps> = ({
  isOpen, onClose, onCreate, mode
}) => {
  const [input, setInput] = useState("");
  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const me = localStorage.getItem("userUid")!;
    const participants = input
      .split(",")
      .map((uid) => uid.trim())
      .filter(Boolean);

    // منطق ذكي حسب الوضع
    if (mode === "global") {
      onCreate([]); // ما نحتاج UIDs
      onClose();
      setInput("");
      return;
    }
    if (mode === "direct") {
      if (participants.length < 1) return; // لازم UID واحد على الأقل
      // ضمّ نفسك إن ما كان موجود
      if (!participants.includes(me)) participants.unshift(me);
    } else if (mode === "department") {
      // إن فاضي، ضيف نفسك على الأقل
      if (participants.length === 0) participants.push(me);
    }

    onCreate(participants);
    setInput("");
    onClose();
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h3>إنشاء دردشة جديدة</h3>
        <form onSubmit={handleSubmit}>
          <label>
            {mode === "direct" ? "UID الشخص الآخر:" : "UIDs مفصولة بفاصلة (اختياري):"}
          </label>

          {/* في الوضع العام نظهر حقل معطل كإيضاح فقط */}
          <input
            type="text"
            placeholder={mode === "direct" ? "otherUid" : "uid1, uid2, uid3"}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={mode === "global"}
          />

          <div className="modal-actions">
            <button type="button" className="btn-cancel" onClick={onClose}>إلغاء</button>
            <button type="submit" className="btn-primary">
              إنشاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewChatModal;
