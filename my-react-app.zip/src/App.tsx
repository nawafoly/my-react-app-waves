// src/App.tsx
import React, { Suspense } from "react";
import { AuthProvider } from "./context/AuthContext";
import AppRouter from "./AppRouter";
import Topbar from "./components/Topbar";
import "./index.css"; // ستايل عام للموقع كله

function App() {
  return (
    <AuthProvider>
      <Suspense fallback={<div>جاري التحميل...</div>}>
        <AppRouter />
      </Suspense>
    </AuthProvider>
  );
}

export default App;
