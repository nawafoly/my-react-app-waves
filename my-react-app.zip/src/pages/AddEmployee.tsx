// src/pages/AddEmployee.tsx
import React, { useState } from "react";
import { createUserLocal } from "../services/AuthService";
import "../styles/add-employee.css"; // استيراد التنسيق

export default function AddEmployee() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("المغسلة");
  const [username, setUsername] = useState(""); // ممكن = الإيميل
  const [password, setPassword] = useState(""); // اختياري: اكتب أو خليه فاضي للتوليد
  const [saving, setSaving] = useState(false);
  const [tempShown, setTempShown] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const { tempPassword } = await createUserLocal({
        name,
        email,
        role,
        username: username || email,
        password: password || undefined,
      });
      setTempShown(tempPassword || null);
      setName(""); setEmail(""); setRole("المغسلة"); setUsername(""); setPassword("");
      alert(`تم إنشاء الحساب.\nالباسورد المؤقت: ${tempPassword}\n⚠️ احفظه وارسله للموظف.`);
    } catch (err: any) {
      alert(err.message || "حدث خطأ");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="ae-wrap">
      <h1 className="ae-title">إضافة موظف جديد</h1>

      <form className="ae-card" onSubmit={handleSubmit} dir="rtl">
        <div className="ae-grid">
          <label className="ae-field">
            <span>اسم الموظف</span>
            <input value={name} onChange={e=>setName(e.target.value)} required />
          </label>

          <label className="ae-field">
            <span>البريد الإلكتروني</span>
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
          </label>

          <label className="ae-field">
            <span>اسم المستخدم</span>
            <input placeholder="مثلاً البريد" value={username} onChange={e=>setUsername(e.target.value)} />
          </label>

          <label className="ae-field">
            <span>القسم / الدور</span>
            <select value={role} onChange={e=>setRole(e.target.value)}>
              <option>المغسلة</option>
              <option>الهاوسكيبنق</option>
              <option>المطبخ</option>
              <option>التسويق</option>
              <option>الحسابات</option>
              <option>الاستقبال</option>
              <option>الصيانة</option>
            </select>
          </label>

          <label className="ae-field ae-span2">
            <span>كلمة المرور (اختياري)</span>
            <input
              type="password"
              placeholder="اتركها فاضية لتوليد باسورد مؤقت"
              value={password}
              onChange={e=>setPassword(e.target.value)}
            />
          </label>
        </div>

        <div className="ae-actions">
          <button className="ae-btn" disabled={saving}>
            {saving ? "جارٍ الحفظ..." : "حفظ المستخدم"}
          </button>
          {tempShown && (
            <div className="ae-temp">آخر باسورد مؤقت تم توليده: <b>{tempShown}</b></div>
          )}
        </div>
      </form>
    </div>
  );
}
