import React, { useEffect } from "react";
import { auth, db } from "../firebase/firebase";

const TestFirebase = () => {
  useEffect(() => {
    console.log("Auth object:", auth);
    console.log("Firestore object:", db);
  }, []);

  return <div>Testing Firebase in console</div>;
};

export default TestFirebase;
