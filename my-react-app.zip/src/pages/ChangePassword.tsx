import React, { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { updatePasswordLocal } from "../services/AuthService";

export default function ChangePassword() {
  const [pwd, setPwd] = useState("");
  const [pwd2, setPwd2] = useState("");
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const navigate = useNavigate();

  const session = useMemo(() => {
    const raw = localStorage.getItem("waves_user");
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw) as { id?: string };
      return parsed?.id ? { userId: parsed.id } : null;
    } catch {
      return null;
    }
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setOk("");
    if (!session?.userId) {
      setErr("الجلسة غير صالحة، الرجاء تسجيل الدخول من جديد.");
      return;
    }
    if (pwd.length < 6) {
      setErr("كلمة المرور يجب أن تتكون من 6 أحرف على الأقل.");
      return;
    }
    if (pwd !== pwd2) {
      setErr("كلمتا المرور غير متطابقتين.");
      return;
    }

    await updatePasswordLocal(session.userId, pwd);
    setOk("تم تحديث كلمة المرور بنجاح!");
    setTimeout(() => navigate("/"), 1500);
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">تغيير كلمة المرور</h1>

      <div className="card p-6 max-w-md mx-auto">
        <form onSubmit={handleSubmit}>
          <div className="form-group mb-4">
            <label htmlFor="newPassword" className="form-label">كلمة المرور الجديدة:</label>
            <input
              id="newPassword"
              type="password"
              className="form-control"
              placeholder="أدخل كلمة المرور الجديدة"
              value={pwd}
              onChange={(e) => setPwd(e.target.value)}
              required
            />
          </div>

          <div className="form-group mb-6">
            <label htmlFor="confirmPassword" className="form-label">تأكيد كلمة المرور الجديدة:</label>
            <input
              id="confirmPassword"
              type="password"
              className="form-control"
              placeholder="أعد إدخال كلمة المرور الجديدة"
              value={pwd2}
              onChange={(e) => setPwd2(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary w-full" disabled={!pwd || !pwd2 || pwd !== pwd2}>
            حفظ كلمة المرور
          </button>

          {err && <p className="text-center mt-4 text-red-600">{err}</p>}
          {ok && <p className="text-center mt-4 text-green-600">{ok}</p>}
        </form>
      </div>
    </div>
  );
}


