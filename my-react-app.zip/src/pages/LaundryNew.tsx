import React, { useMemo, useState } from "react";
import {
  laundryItems,
  LaundryOrderItem,
  calcTotals,
  createOrder,
} from "../services/LaundryService";
import "../styles/laundry.css";

export default function LaundryNew() {
  const items = useMemo(() => laundryItems, []);
  const [room, setRoom] = useState("");
  const [note, setNote] = useState("");
  const [sel, setSel] = useState(items[0]?.id || "");
  const [qty, setQty] = useState(1);
  const [orderItems, setOrderItems] = useState<LaundryOrderItem[]>([]);
  const [washType, setWashType] = useState(""); // New state for wash type
  const [priority, setPriority] = useState(""); // New state for priority

  function addItem(e: React.FormEvent) {
    e.preventDefault();
    if (!sel || qty <= 0) return;
    setOrderItems((prev) => {
      const i = prev.findIndex((p) => p.itemId === sel);
      if (i > -1) {
        const copy = [...prev];
        copy[i] = { ...copy[i], qty: copy[i].qty + qty };
        return copy;
      }
      return [...prev, { itemId: sel, qty }];
    });
    setQty(1);
  }

  function removeItem(id: string) {
    setOrderItems((prev) => prev.filter((p) => p.itemId !== id));
  }

  const totals = calcTotals(orderItems, items);

  async function save() {
    if (!room.trim() || orderItems.length === 0) {
      alert("أدخل رقم الغرفة وأضف عناصر.");
      return;
    }
    if (!washType) {
      alert("الرجاء اختيار نوع الغسيل (غسيل أو كي).");
      return;
    }
    if (!priority) {
      alert("الرجاء اختيار الأولوية (عاجل أو عادي).");
      return;
    }

    const res = createOrder({
      roomNumber: room,
      items: orderItems,
      notes: `${note} | نوع الغسيل: ${washType} | الأولوية: ${priority}`,
    });
    if (!res.ok) return alert(res.error);
    const order = res.data;
    alert(`تم حفظ الطلب #${order.id}\nالإجمالي: ${order.total} SAR`);
    setRoom("");
    setNote("");
    setSel(items[0]?.id || "");
    setQty(1);
    setOrderItems([]);
    setWashType("");
    setPriority("");
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">إنشاء طلب مغسلة جديد</h1>

      <div className="card p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">تفاصيل الطلب</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="form-group">
            <label htmlFor="roomNumber" className="form-label">رقم الغرفة:</label>
            <input
              id="roomNumber"
              type="text"
              className="form-control"
              placeholder="مثال: 101"
              value={room}
              onChange={(e) => setRoom(e.target.value.replace(/[^\d]/g, ""))}
              inputMode="numeric"
              pattern="[0-9]*"
              dir="ltr"
              title="اكتب أرقام الغرفة فقط"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="note" className="form-label">ملاحظات (اختياري):</label>
            <textarea
              id="note"
              className="form-control"
              placeholder="أي تعليمات خاصة..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={1}
            ></textarea>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="form-group">
            <label htmlFor="washType" className="form-label">نوع الغسيل:</label>
            <select
              id="washType"
              className="form-control"
              value={washType}
              onChange={(e) => setWashType(e.target.value)}
              required
            >
              <option value="">اختر نوع الغسيل</option>
              <option value="wash">غسيل</option>
              <option value="iron">كي</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="priority" className="form-label">الأولوية:</label>
            <select
              id="priority"
              className="form-control"
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              required
            >
              <option value="">اختر الأولوية</option>
              <option value="urgent">عاجل</option>
              <option value="regular">عادي</option>
            </select>
          </div>
        </div>
      </div>

      <div className="card p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">إضافة عناصر الغسيل</h2>
        <form onSubmit={addItem} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="form-group">
            <label htmlFor="itemSelect" className="form-label">الصنف:</label>
            <select id="itemSelect" className="form-control" value={sel} onChange={(e) => setSel(e.target.value)}>
              {items.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.nameAr} — {i.price} ر.س
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="quantity" className="form-label">الكمية:</label>
            <input
              id="quantity"
              type="number"
              min={1}
              step={1}
              className="form-control"
              value={qty}
              onChange={(e) => setQty(+e.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-primary h-10">إضافة</button>
        </form>
      </div>

      <div className="card p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">العناصر المطلوبة</h2>
        {orderItems.length === 0 ? (
          <div className="text-center py-4 text-gray-500">
            <p>لا توجد عناصر في الطلب بعد.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="table-auto w-full">
              <thead>
                <tr className="bg-gray-100 text-gray-700 uppercase text-sm leading-normal">
                  <th className="py-3 px-6 text-left">الصنف</th>
                  <th className="py-3 px-6 text-center">السعر</th>
                  <th className="py-3 px-6 text-center">الكمية</th>
                  <th className="py-3 px-6 text-center">الإجمالي</th>
                  <th className="py-3 px-6 text-center"></th>
                </tr>
              </thead>
              <tbody className="text-gray-600 text-sm font-light">
                {orderItems.map((oi) => {
                  const meta = items.find((x) => x.id === oi.itemId)!;
                  return (
                    <tr key={oi.itemId} className="border-b border-gray-200 hover:bg-gray-100">
                      <td className="py-3 px-6 text-left">{meta.nameAr}</td>
                      <td className="py-3 px-6 text-center">{meta.price.toFixed(2)}</td>
                      <td className="py-3 px-6 text-center">{oi.qty}</td>
                      <td className="py-3 px-6 text-center">{(meta.price * oi.qty).toFixed(2)}</td>
                      <td className="py-3 px-6 text-center">
                        <button type="button" onClick={() => removeItem(oi.itemId)} className="btn btn-danger btn-sm">
                          حذف
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <div className="card p-6 w-full md:w-1/2 lg:w-1/3">
          <h2 className="text-xl font-semibold mb-4">ملخص الطلب</h2>
          <div className="flex justify-between py-2 border-b">
            <span className="text-gray-700">المجموع قبل الضريبة</span>
            <b className="text-gray-800">{totals.subtotal.toFixed(2)} ر.س</b>
          </div>
          <div className="flex justify-between py-2 border-b">
            <span className="text-gray-700">الضريبة (15%)</span>
            <b className="text-gray-800">{totals.vat.toFixed(2)} ر.س</b>
          </div>
          <div className="flex justify-between py-2 font-bold text-lg border-b-2 border-primary">
            <span className="text-gray-800">الإجمالي</span>
            <b className="text-primary">{totals.total.toFixed(2)} ر.س</b>
          </div>
          <button
            onClick={save}
            className="btn btn-success w-full mt-6"
            disabled={!room || orderItems.length === 0 || !washType || !priority}
          >
            حفظ الطلب
          </button>
        </div>
      </div>
    </div>
  );
}


