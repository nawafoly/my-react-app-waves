import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function SupervisorDashboard() {
  const { user } = useAuth();

  return (
    <div className="container">
      <h1 className="text-2xl font-bold mb-4">مرحباً بك، {user?.name || "المشرف"}!</h1>
      <p className="text-gray-600 mb-6">هذه لوحة التحكم الخاصة بك. يمكنك الإشراف على مهام الأقسام المختلفة.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">إدارة التدبير المنزلي</h2>
          <p className="text-gray-500 mb-4">مراقبة وتعيين مهام التدبير المنزلي.</p>
          <Link to="/housekeeping" className="btn btn-primary">إدارة التدبير المنزلي</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">إدارة الغسيل</h2>
          <p className="text-gray-500 mb-4">مراقبة طلبات الغسيل وحالتها.</p>
          <Link to="/laundry/orders" className="btn btn-primary">إدارة الغسيل</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">التقارير</h2>
          <p className="text-gray-500 mb-4">عرض التقارير اليومية والشهرية.</p>
          <Link to="/owner/reports" className="btn btn-primary">عرض التقارير</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">الإشعارات</h2>
          <p className="text-gray-500 mb-4">عرض الإشعارات الجديدة.</p>
          <Link to="/notifications" className="btn btn-secondary">عرض الإشعارات</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">الدردشة</h2>
          <p className="text-gray-500 mb-4">التواصل مع الموظفين.</p>
          <Link to="/chat" className="btn btn-secondary">فتح الدردشة</Link>
        </div>
      </div>
    </div>
  );
}


