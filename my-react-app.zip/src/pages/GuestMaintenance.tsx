import React, { useState } from "react";
import { createRequest } from "../services/RequestsService";
import { useAuth } from "../context/AuthContext";

export default function GuestMaintenance() {
  const { user } = useAuth();
  const [issueType, setIssueType] = useState("");
  const [location, setLocation] = useState("");
  const [notes, setNotes] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setMessage("الرجاء تسجيل الدخول لتقديم الطلب.");
      return;
    }

    const newRequest = {
      department: "maintenance",
      type: issueType,
      details: `الموقع: ${location}, ملاحظات: ${notes}`,
      status: "pending",
      createdBy: user.id,
      roomNumber: user.roomNumber || "N/A",
    };

    const res = await createRequest(newRequest);
    if (res.ok) {
      setMessage("تم إرسال طلب الصيانة بنجاح!");
      setIssueType("");
      setLocation("");
      setNotes("");
    } else {
      setMessage(`فشل إرسال الطلب: ${res.error}`);
    }
  };

  return (
    <div className="container py-8">
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">طلب صيانة</h1>
        <p className="text-gray-600">املأ النموذج أدناه للإبلاغ عن مشكلة صيانة.</p>
      </header>

      <section className="card p-6">
        <form onSubmit={handleSubmit}>
          <div className="form-group mb-4">
            <label htmlFor="issueType" className="form-label">نوع المشكلة:</label>
            <select
              id="issueType"
              className="form-control"
              value={issueType}
              onChange={(e) => setIssueType(e.target.value)}
              required
            >
              <option value="">اختر نوع المشكلة</option>
              <option value="plumbing">سباكة</option>
              <option value="electrical">كهرباء</option>
              <option value="ac">تكييف</option>
              <option value="furniture">أثاث</option>
              <option value="other">أخرى</option>
            </select>
          </div>

          <div className="form-group mb-4">
            <label htmlFor="location" className="form-label">الموقع في الغرفة (اختياري):</label>
            <input
              type="text"
              id="location"
              className="form-control"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>

          <div className="form-group mb-4">
            <label htmlFor="notes" className="form-label">وصف المشكلة:</label>
            <textarea
              id="notes"
              className="form-control"
              rows={4}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              required
            ></textarea>
          </div>

          <button type="submit" className="btn btn-primary w-full">
            إرسال الطلب
          </button>

          {message && <p className="text-center mt-4 text-green-600">{message}</p>}
        </form>
      </section>
    </div>
  );
}


