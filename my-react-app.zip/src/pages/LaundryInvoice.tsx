import React, { useMemo } from "react";
import { useParams } from "react-router-dom";
import { getOrder, laundryItems } from "../services/LaundryService";
import "../styles/invoice.css"; // Keep existing invoice styles for specific elements

export default function LaundryInvoice() {
  const { id } = useParams();
  const order = useMemo(() => {
    if (!id) return undefined;
    const res = getOrder(id);
    return res.ok ? res.data : undefined;
  }, [id]);

  if (!order) {
    return (
      <div className="container text-center py-8">
        <p className="text-xl text-gray-700">الطلب غير موجود.</p>
      </div>
    );
  }

  const itemsMap = new Map(laundryItems.map((i) => [i.id, i]));
  const created = new Date(order.createdAt);
  const fmt = new Intl.DateTimeFormat("ar-SA", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(created);

  return (
    <div className="container py-8">
      <div className="card p-8 shadow-lg">
        <header className="flex justify-between items-center mb-8 border-b pb-4">
          <div>
            <h1 className="text-3xl font-bold text-primary mb-2">فاتورة المغسلة</h1>
            <div className="text-gray-600">تاريخ: {fmt}</div>
            <div className="text-gray-600 ltr">رقم الطلب: {order.id.slice(0, 8)}</div>
          </div>
          <div className="text-right">
            <strong className="text-2xl text-accent">Waves Hotel</strong>
            <div className="text-gray-600">قسم المغسلة</div>
            <div className="text-gray-600 ltr">رقم الغرفة: {order.roomNumber}</div>
          </div>
        </header>

        <table className="table-auto w-full mb-8">
          <thead>
            <tr className="bg-gray-100 text-gray-700 uppercase text-sm leading-normal">
              <th className="py-3 px-6 text-left">الصنف</th>
              <th className="py-3 px-6 text-center">السعر (ر.س)</th>
              <th className="py-3 px-6 text-center">الكمية</th>
              <th className="py-3 px-6 text-center">الإجمالي (ر.س)</th>
            </tr>
          </thead>
          <tbody className="text-gray-600 text-sm font-light">
            {order.items.map((row) => {
              const meta = itemsMap.get(row.itemId)!;
              return (
                <tr key={row.itemId} className="border-b border-gray-200 hover:bg-gray-100">
                  <td className="py-3 px-6 text-left whitespace-nowrap">{meta?.nameAr || row.itemId}</td>
                  <td className="py-3 px-6 text-center">{meta.price.toFixed(2)}</td>
                  <td className="py-3 px-6 text-center">{row.qty}</td>
                  <td className="py-3 px-6 text-center">
                    {(meta.price * row.qty).toFixed(2)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        <div className="flex justify-end mb-8">
          <div className="w-full md:w-1/2 lg:w-1/3">
            <div className="flex justify-between py-2 border-b">
              <span className="text-gray-700">المجموع قبل الضريبة</span>
              <b className="text-gray-800">{order.subtotal.toFixed(2)} ر.س</b>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span className="text-gray-700">الضريبة (15%)</span>
              <b className="text-gray-800">{order.vat.toFixed(2)} ر.س</b>
            </div>
            <div className="flex justify-between py-2 font-bold text-lg border-b-2 border-primary">
              <span className="text-gray-800">الإجمالي</span>
              <b className="text-primary">{order.total.toFixed(2)} ر.س</b>
            </div>
          </div>
        </div>

        {order.notes && <div className="card p-4 bg-gray-50 text-gray-700 mb-8">ملاحظات: {order.notes}</div>}

        <div className="flex justify-center no-print">
          <button onClick={() => window.print()} className="btn btn-primary text-lg px-8 py-3">
            طباعة الفاتورة
          </button>
        </div>
      </div>
    </div>
  );
}


