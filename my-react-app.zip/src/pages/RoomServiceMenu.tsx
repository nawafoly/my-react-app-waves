import React from "react";
import "../styles/RoomService.css";

const menuItems = [
  {
    category: "الإفطار",
    items: [
      { id: "1", name: "فطور كونتيننتال", description: "بيض، خبز محمص، مربى، زبدة، قهوة/شاي", price: 45 },
      { id: "2", name: "فطور شرقي", description: "فول، فلافل، جبنة، زيتون، شاي بالنعناع", price: 55 },
    ],
  },
  {
    category: "الأطباق الرئيسية",
    items: [
      { id: "3", name: "ستيك لحم", description: "مع بطاطس مهروسة وخضروات مشوية", price: 120 },
      { id: "4", name: "سلمون مشوي", description: "مع أرز بالخضار وصلصة الليمون", price: 95 },
      { id: "5", name: "باستا الفريدو", description: "مكرونة بالدجاج وصلصة الكريمة والفطر", price: 70 },
    ],
  },
  {
    category: "الحلويات",
    items: [
      { id: "6", name: "كيك الشوكولاتة", description: "كيك غني بالشوكولاتة مع آيس كريم فانيليا", price: 35 },
      { id: "7", name: "أم علي", description: "حلوى مصرية تقليدية بالمكسرات والقشطة", price: 30 },
    ],
  },
  {
    category: "المشروبات",
    items: [
      { id: "8", name: "عصير برتقال طازج", description: "", price: 20 },
      { id: "9", name: "قهوة", description: "", price: 15 },
      { id: "10", name: "شاي", description: "", price: 15 },
    ],
  },
];

export default function RoomServiceMenu() {
  return (
    <div className="container py-8">
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">قائمة خدمة الغرف</h1>
        <p className="text-gray-600">اختر من قائمتنا المتنوعة واستمتع بوجبتك في غرفتك.</p>
      </header>

      {menuItems.map((categoryData) => (
        <section key={categoryData.category} className="mb-8">
          <h2 className="text-2xl font-semibold mb-4 border-b pb-2">{categoryData.category}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categoryData.items.map((item) => (
              <div key={item.id} className="card p-6 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-bold mb-2">{item.name}</h3>
                  {item.description && <p className="text-gray-500 mb-4">{item.description}</p>}
                </div>
                <div className="flex justify-between items-center mt-4">
                  <span className="text-primary text-lg font-semibold">{item.price.toFixed(2)} ر.س</span>
                  <button className="btn btn-primary">إضافة للطلب</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}

      <div className="text-center mt-8">
        <p className="text-gray-500">لتقديم طلب، يرجى استخدام بوابة الضيف أو الاتصال بالاستقبال.</p>
      </div>
    </div>
  );
}


