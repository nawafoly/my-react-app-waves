// src/pages/SetupOwner.tsx
import React, { useState } from "react";
import { registerUser, Role } from "../services/userSetup";

export default function SetupOwner() {
  const [status, setStatus] = useState("");

  const handleCreateOwner = async () => {
    setStatus("جاري الإنشاء...");
    try {
      const uid = await registerUser({
        email: "owner@waves.com",
        password: "Password123!",
        name: "مالك الفندق",
        role: "owner",
        department: null, // إذا الدالة تسمح
      });
      setStatus(`تم الإنشاء بنجاح. UID: ${uid}`);
    } catch (e: any) {
      setStatus("فشل الإنشاء: " + e.message);
    }
  };

  return (
    <div style={{ padding: 24 }}>
      <h2>إنشاء مالك</h2>
      <button onClick={handleCreateOwner}>إنشاء owner@waves.com</button>
      <p>{status}</p>
    </div>
  );
}
