import React, { useState } from "react";
import { createRequest } from "../services/RequestsService";
import { useAuth } from "../context/AuthContext";

export default function GuestHousekeeping() {
  const { user } = useAuth();
  const [serviceType, setServiceType] = useState("");
  const [preferredTime, setPreferredTime] = useState("");
  const [notes, setNotes] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setMessage("الرجاء تسجيل الدخول لتقديم الطلب.");
      return;
    }

    const newRequest = {
      department: "housekeeping",
      type: serviceType,
      details: `الوقت المفضل: ${preferredTime}, ملاحظات: ${notes}`,
      status: "pending",
      createdBy: user.id,
      roomNumber: user.roomNumber || "N/A",
    };

    const res = await createRequest(newRequest);
    if (res.ok) {
      setMessage("تم إرسال طلب التنظيف بنجاح!");
      setServiceType("");
      setPreferredTime("");
      setNotes("");
    } else {
      setMessage(`فشل إرسال الطلب: ${res.error}`);
    }
  };

  return (
    <div className="container py-8">
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">طلب خدمة تنظيف الغرف</h1>
        <p className="text-gray-600">املأ النموذج أدناه لطلب خدمة تنظيف لغرفتك.</p>
      </header>

      <section className="card p-6">
        <form onSubmit={handleSubmit}>
          <div className="form-group mb-4">
            <label htmlFor="serviceType" className="form-label">نوع الخدمة:</label>
            <select
              id="serviceType"
              className="form-control"
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
              required
            >
              <option value="">اختر نوع الخدمة</option>
              <option value="full_clean">تنظيف كامل</option>
              <option value="towel_change">تغيير المناشف</option>
              <option value="amenities_refill">إعادة تعبئة المستلزمات</option>
              <option value="quick_tidy">ترتيب سريع</option>
            </select>
          </div>

          <div className="form-group mb-4">
            <label htmlFor="preferredTime" className="form-label">الوقت المفضل:</label>
            <input
              type="datetime-local"
              id="preferredTime"
              className="form-control"
              value={preferredTime}
              onChange={(e) => setPreferredTime(e.target.value)}
              required
            />
          </div>

          <div className="form-group mb-4">
            <label htmlFor="notes" className="form-label">ملاحظات إضافية:</label>
            <textarea
              id="notes"
              className="form-control"
              rows={4}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            ></textarea>
          </div>

          <button type="submit" className="btn btn-primary w-full">
            إرسال الطلب
          </button>

          {message && <p className="text-center mt-4 text-green-600">{message}</p>}
        </form>
      </section>
    </div>
  );
}


