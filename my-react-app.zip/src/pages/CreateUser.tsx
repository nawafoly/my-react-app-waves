import React, { useState, useEffect } from "react";
import {
  createUserLocal,
  Department,
  Perm,
  PERMS,
  DEPT_PERMISSIONS,
  Role,
} from "../services/AuthService";

export default function CreateUser() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<Role>("employee");
  const [dept, setDept] = useState<Department | "">("");
  const [mustChangePassword, setMustChangePassword] = useState(true);
  const [extraPerms, setExtraPerms] = useState<Perm[]>([]);
  const [saving, setSaving] = useState(false);
  const [tempPassword, setTempPassword] = useState<string | null>(null);

  useEffect(() => {
    if (role === "employee" && dept && DEPT_PERMISSIONS[dept]) {
      setExtraPerms(DEPT_PERMISSIONS[dept]);
    } else {
      setExtraPerms([]);
    }
  }, [dept, role]);

  function togglePerm(perm: Perm) {
    setExtraPerms((prev) =>
      prev.includes(perm) ? prev.filter((p) => p !== perm) : [...prev, perm]
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const { tempPassword } = await createUserLocal({
        name,
        email,
        username: username || email,
        password: password || undefined,
        role,
        dept: dept || undefined,
        perms: extraPerms,
        mustChangePassword,
      });

      setTempPassword(tempPassword || null);
      alert(`✅ تم إنشاء المستخدم.\nالباسورد المؤقت: ${tempPassword || password}\n⚠️ انسخه وأرسله للموظف.`);

      setName(""); setEmail(""); setUsername(""); setPassword("");
      setRole("employee"); setDept(""); setExtraPerms([]); setMustChangePassword(true);
    } catch (err: any) {
      alert(err.message || "❌ حدث خطأ غير متوقع");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">إنشاء مستخدم جديد</h1>

      <div className="card p-6">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="form-group">
              <label htmlFor="name" className="form-label">الاسم:</label>
              <input
                id="name"
                type="text"
                className="form-control"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="email" className="form-label">البريد الإلكتروني:</label>
              <input
                id="email"
                type="email"
                className="form-control"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="username" className="form-label">اسم المستخدم:</label>
              <input
                id="username"
                type="text"
                className="form-control"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="اتركه فارغًا لاستخدام البريد الإلكتروني"
              />
            </div>

            <div className="form-group">
              <label htmlFor="role" className="form-label">الدور:</label>
              <select
                id="role"
                className="form-control"
                value={role}
                onChange={(e) => setRole(e.target.value as Role)}
              >
                <option value="owner">مالك</option>
                <option value="supervisor">مشرف</option>
                <option value="employee">موظف</option>
                <option value="guest">ضيف</option>
              </select>
            </div>

            {role === "employee" && (
              <div className="form-group">
                <label htmlFor="dept" className="form-label">القسم:</label>
                <select
                  id="dept"
                  className="form-control"
                  value={dept}
                  onChange={(e) => setDept(e.target.value as Department)}
                >
                  <option value="">اختر القسم</option>
                  <option value="laundry">المغسلة</option>
                  <option value="kitchen">المطبخ</option>
                  <option value="housekeeping">التدبير المنزلي</option>
                  <option value="frontdesk">الاستقبال</option>
                </select>
              </div>
            )}

            <div className="form-group col-span-full">
              <label htmlFor="password" className="form-label">كلمة المرور (اختياري):</label>
              <input
                id="password"
                type="password"
                className="form-control"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="اتركها فارغة للتوليد التلقائي"
              />
            </div>

            <div className="form-group col-span-full flex items-center">
              <input
                id="mustChangePassword"
                type="checkbox"
                className="form-checkbox"
                checked={mustChangePassword}
                onChange={(e) => setMustChangePassword(e.target.checked)}
              />
              <label htmlFor="mustChangePassword" className="ml-2 text-gray-700">إجبار تغيير كلمة المرور عند أول دخول</label>
            </div>

            <div className="form-group col-span-full">
              <span className="form-label block mb-2">الصلاحيات الإضافية:</span>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                {Object.values(PERMS).map((perm) => (
                  <label key={perm} className="flex items-center">
                    <input
                      type="checkbox"
                      className="form-checkbox"
                      checked={extraPerms.includes(perm)}
                      onChange={() => togglePerm(perm)}
                    />
                    <span className="ml-2 text-gray-700 text-sm">{perm}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end mt-6">
            <button type="submit" className="btn btn-primary px-6 py-3" disabled={saving}>
              {saving ? "جارٍ الإنشاء..." : "إنشاء المستخدم"}
            </button>
          </div>

          {tempPassword && (
            <div className="card p-4 bg-yellow-100 text-yellow-800 mt-4 text-center">
              آخر كلمة مرور مؤقتة تم إنشاؤها: <b className="ltr">{tempPassword}</b><br />
              <span className="text-sm">⚠️ يرجى نسخها وإرسالها للمستخدم.</span>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}


