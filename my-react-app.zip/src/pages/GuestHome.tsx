import React from "react";
import { Link } from "react-router-dom";
import "../styles/GuestHome.css";

export default function GuestHome() {
  return (
    <div className="container">
      <header className="mb-6 text-center">
        <h1 className="text-3xl font-bold mb-2">مرحبًا بك في فندق Waves!</h1>
        <p className="text-gray-600">اختر خدمة لتبدأ.</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Link to="/laundry/new" className="card p-6 text-center hover:shadow-lg transition-shadow duration-300">
          <h2 className="text-xl font-semibold mb-2">خدمة الغسيل</h2>
          <p className="text-gray-500">اطلب خدمة غسيل وكي الملابس.</p>
        </Link>
        <Link to="/room-service/menu" className="card p-6 text-center hover:shadow-lg transition-shadow duration-300">
          <h2 className="text-xl font-semibold mb-2">خدمة الغرف</h2>
          <p className="text-gray-500">اطلب الطعام والمشروبات إلى غرفتك.</p>
        </Link>
        <Link to="/guest/housekeeping" className="card p-6 text-center hover:shadow-lg transition-shadow duration-300">
          <h2 className="text-xl font-semibold mb-2">التدبير المنزلي</h2>
          <p className="text-gray-500">اطلب تنظيف الغرفة أو مستلزمات إضافية.</p>
        </Link>
        <Link to="/guest/maintenance" className="card p-6 text-center hover:shadow-lg transition-shadow duration-300">
          <h2 className="text-xl font-semibold mb-2">الصيانة</h2>
          <p className="text-gray-500">أبلغ عن أي مشكلة صيانة في غرفتك.</p>
        </Link>
      </section>

      <section className="card p-6">
        <h2 className="text-xl font-semibold mb-4">طلباتي</h2>
        <div className="text-gray-500">
          <p>لا توجد طلبات حالية. ابدأ بطلب خدمة جديدة!</p>
        </div>
      </section>
    </div>
  );
}


