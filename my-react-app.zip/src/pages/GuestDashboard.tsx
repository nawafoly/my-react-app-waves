// src/pages/GuestDashboard.tsx
import React, { useMemo, useState } from "react";
import { createRequest, listRequests } from "../services/RequestsService";
import { useAuth } from "../context/AuthContext";
import "../styles/GuestHome.css";

export default function GuestDashboard() {
  const { user } = useAuth();
  const [note, setNote] = useState("");
  const [refresh, setRefresh] = useState(0);

  const myRequests = useMemo(() => {
    if (!user) return [];
    const res = listRequests({ createdBy: user.id });
    return res.ok ? res.data : [];
  }, [user, refresh]);

  function makeLaundry() {
    if (!user) return;
    const res = createRequest({ department: "laundry", createdBy: user.id, roomNumber: "", notes: note, items: [] } as any);
    if (!res.ok) return alert(res.error);
    setNote("");
    setRefresh((x) => x + 1);
  }

  function makeFood() {
    if (!user) return;
    const res = createRequest({ department: "room-service", createdBy: user.id, roomNumber: "", notes: note, items: [] } as any);
    if (!res.ok) return alert(res.error);
    setNote("");
    setRefresh((x) => x + 1);
  }

  function makeHousekeeping() {
    if (!user) return;
    const res = createRequest({ department: "housekeeping", createdBy: user.id, roomNumber: "", notes: note, details: "" } as any);
    if (!res.ok) return alert(res.error);
    setNote("");
    setRefresh((x) => x + 1);
  }

  function makeMaintenance() {
    if (!user) return;
    const res = createRequest({ department: "maintenance", createdBy: user.id, roomNumber: "", notes: note, details: "" } as any);
    if (!res.ok) return alert(res.error);
    setNote("");
    setRefresh((x) => x + 1);
  }

  return (
    <div className="guest-home" dir="rtl">
      <h1>بوابة الضيف</h1>
      <div className="cards">
        <div className="card">
          <h3>استلام غسيل</h3>
          <input className="input" placeholder="ملاحظات" value={note} onChange={(e) => setNote(e.target.value)} />
          <button className="btn" onClick={makeLaundry}>طلب غسيل</button>
        </div>
        <div className="card">
          <h3>طلب طعام</h3>
          <button className="btn" onClick={makeFood}>القائمة</button>
        </div>
        <div className="card">
          <h3>طلب تنظيف</h3>
          <button className="btn" onClick={makeHousekeeping}>طلب خدمة</button>
        </div>
        <div className="card">
          <h3>طلب صيانة</h3>
          <button className="btn" onClick={makeMaintenance}>فتح تذكرة</button>
        </div>
      </div>

      <h2>طلباتي</h2>
      <div className="card">
        {myRequests.length === 0 ? (
          <div className="muted">لا توجد طلبات حتى الآن.</div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>القسم</th>
                <th>الحالة</th>
                <th>التاريخ</th>
                <th>ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              {myRequests.map((r) => (
                <tr key={r.id}>
                  <td>{r.department}</td>
                  <td>{r.status}</td>
                  <td>{new Date(r.createdAt).toLocaleString()}</td>
                  <td>{r.notes || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
