import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  listOrders,
  updateOrderStatus,
  deleteOrder,
  LaundryOrder,
} from "../services/LaundryService";

export default function LaundryOrders() {
  const [qRoom, setQRoom] = useState("");
  const [qStatus, setQStatus] = useState<"all" | LaundryOrder["status"]>("all");
  const [refresh, setRefresh] = useState(0);

  const orders = useMemo(() => {
    const res = listOrders();
    return res.ok ? res.data : [];
  }, [refresh]);

  const filtered = orders.filter((o) => {
    const roomOk = qRoom ? o.roomNumber.includes(qRoom) : true;
    const statusOk = qStatus === "all" ? true : o.status === qStatus;
    return roomOk && statusOk;
  });

  function setStatus(id: string, status: LaundryOrder["status"]) {
    const res = updateOrderStatus(id, status);
    if (res.ok) setRefresh((x) => x + 1);
    else alert(res.error);
  }

  function remove(id: string) {
    if (!confirm("هل أنت متأكد من حذف هذا الطلب؟")) return;
    const res = deleteOrder(id);
    if (res.ok) setRefresh((x) => x + 1);
    else alert(res.error);
  }

  const getWashTypeAndPriority = (notes: string) => {
    const washTypeMatch = notes.match(/نوع الغسيل: (\S+)/);
    const priorityMatch = notes.match(/الأولوية: (\S+)/);
    return {
      washType: washTypeMatch ? washTypeMatch[1] : "غير محدد",
      priority: priorityMatch ? priorityMatch[1] : "غير محدد",
    };
  };

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">طلبات المغسلة</h1>

      <div className="card p-6 mb-6 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
          <select
            className="form-control w-full md:w-auto"
            value={qStatus}
            onChange={(e) => setQStatus(e.target.value as any)}
          >
            <option value="all">كل الحالات</option>
            <option value="received">مستلم</option>
            <option value="washing">غسيل</option>
            <option value="ironing">كي</option>
            <option value="ready">جاهز</option>
            <option value="delivered">مُسلّم</option>
            <option value="canceled">ملغي</option>
          </select>

          <input
            className="form-control w-full md:w-auto"
            placeholder="بحث برقم الغرفة"
            value={qRoom}
            onChange={(e) => setQRoom(e.target.value)}
          />
        </div>

        <Link
          to="/laundry/new"
          className="btn btn-primary w-full md:w-auto"
        >
          + طلب جديد
        </Link>
      </div>

      <div className="card p-6">
        {filtered.length === 0 ? (
          <div className="text-center py-4 text-gray-500">
            <p>لا توجد طلبات مغسلة مطابقة للمعايير المحددة.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="table-auto w-full">
              <thead>
                <tr className="bg-gray-100 text-gray-700 uppercase text-sm leading-normal">
                  <th className="py-3 px-6 text-left">رقم الطلب</th>
                  <th className="py-3 px-6 text-left">الغرفة</th>
                  <th className="py-3 px-6 text-left">الحالة</th>
                  <th className="py-3 px-6 text-left">نوع الغسيل</th>
                  <th className="py-3 px-6 text-left">الأولوية</th>
                  <th className="py-3 px-6 text-right">الإجمالي (ر.س)</th>
                  <th className="py-3 px-6 text-center">إجراءات</th>
                </tr>
              </thead>
              <tbody className="text-gray-600 text-sm font-light">
                {filtered.map((o) => {
                  const { washType, priority } = getWashTypeAndPriority(o.notes || "");
                  return (
                    <tr key={o.id} className="border-b border-gray-200 hover:bg-gray-100">
                      <td className="py-3 px-6 text-left ltr">{o.id.slice(0, 8)}</td>
                      <td className="py-3 px-6 text-left">{o.roomNumber}</td>
                      <td className="py-3 px-6 text-left">
                        <span className={`badge ${o.status === "delivered" ? "badge-success" : o.status === "canceled" ? "badge-danger" : "badge-info"}`}>
                          {statusLabel(o.status)}
                        </span>
                      </td>
                      <td className="py-3 px-6 text-left">{washType}</td>
                      <td className="py-3 px-6 text-left">{priority}</td>
                      <td className="py-3 px-6 text-right font-bold">{o.total.toFixed(2)}</td>
                      <td className="py-3 px-6 text-center">
                        <div className="flex justify-center items-center gap-2 flex-wrap">
                          {o.status === "received" && (
                            <button
                              className="btn btn-sm btn-primary"
                              onClick={() => setStatus(o.id, "washing")}
                            >
                              بدء الغسيل
                            </button>
                          )}
                          {o.status === "washing" && (
                            <button
                              className="btn btn-sm btn-warning"
                              onClick={() => setStatus(o.id, "ironing")}
                            >
                              بدء الكي
                            </button>
                          )}
                          {o.status === "ironing" && (
                            <button
                              className="btn btn-sm btn-success"
                              onClick={() => setStatus(o.id, "ready")}
                            >
                              جاهز
                            </button>
                          )}
                          {o.status === "ready" && (
                            <button
                              className="btn btn-sm btn-info"
                              onClick={() => setStatus(o.id, "delivered")}
                            >
                              تسليم
                            </button>
                          )}
                          <Link className="btn btn-sm btn-secondary" to={`/laundry/invoice/${o.id}`}>
                            فاتورة
                          </Link>
                          <button className="btn btn-sm btn-danger" onClick={() => remove(o.id)}>
                            حذف
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function statusLabel(s: LaundryOrder["status"]) {
  switch (s) {
    case "received":
      return "مستلم";
    case "washing":
      return "غسيل";
    case "ironing":
      return "كي";
    case "ready":
      return "جاهز";
    case "delivered":
      return "مُسلّم";
    case "canceled":
      return "ملغي";
    default:
      return s;
  }
}


