import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function EmployeeDashboard() {
  const { user } = useAuth();

  return (
    <div className="container">
      <h1 className="text-2xl font-bold mb-4">مرحباً بك، {user?.name || "موظف"}!</h1>
      <p className="text-gray-600 mb-6">هذه لوحة التحكم الخاصة بك. يمكنك الوصول إلى المهام الخاصة بقسمك.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {user?.dept === "housekeeping" && (
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-2">إدارة الغرف</h2>
            <p className="text-gray-500 mb-4">عرض وتحديث حالة الغرف.</p>
            <Link to="/housekeeping" className="btn btn-primary">انتقل إلى إدارة الغرف</Link>
          </div>
        )}

        {user?.dept === "kitchen" && (
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-2">طلبات المطبخ</h2>
            <p className="text-gray-500 mb-4">عرض وإدارة طلبات خدمة الغرف.</p>
            <Link to="/room-service/menu" className="btn btn-primary">انتقل إلى طلبات المطبخ</Link>
          </div>
        )}

        {user?.dept === "laundry" && (
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-2">إدارة الغسيل</h2>
            <p className="text-gray-500 mb-4">عرض وإدارة طلبات الغسيل.</p>
            <Link to="/laundry/orders" className="btn btn-primary">انتقل إلى إدارة الغسيل</Link>
          </div>
        )}

        {user?.dept === "frontdesk" && (
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-2">الاستقبال</h2>
            <p className="text-gray-500 mb-4">إدارة حجوزات النزلاء وتسجيل الدخول/الخروج.</p>
            <Link to="/guest/requests" className="btn btn-primary">انتقل إلى الاستقبال</Link>
          </div>
        )}

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">الإشعارات</h2>
          <p className="text-gray-500 mb-4">عرض الإشعارات الجديدة.</p>
          <Link to="/notifications" className="btn btn-secondary">عرض الإشعارات</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">الدردشة</h2>
          <p className="text-gray-500 mb-4">التواصل مع الزملاء.</p>
          <Link to="/chat" className="btn btn-secondary">فتح الدردشة</Link>
        </div>
      </div>
    </div>
  );
}


