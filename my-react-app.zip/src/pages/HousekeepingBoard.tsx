import React, { useState, useEffect } from "react";

type Status = "to-clean" | "in-progress" | "done";

type RoomTask = {
  id: string;
  roomNumber: string;
  guestName?: string;
  assignedTo?: string;
  status: Status;
};

const initialTasks: RoomTask[] = [
  { id: "r101", roomNumber: "101", guestName: "أحمد", status: "to-clean" },
  { id: "r102", roomNumber: "102", guestName: "منى", status: "in-progress" },
  { id: "r103", roomNumber: "103", guestName: "سارة", status: "done" },
];

const STORAGE_KEY = "housekeeping_tasks";

const HousekeepingBoard: React.FC = () => {
  const [tasks, setTasks] = useState<RoomTask[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setTasks(JSON.parse(saved));
    } else {
      setTasks(initialTasks);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  }, [tasks]);

  const updateStatus = (id: string, newStatus: Status) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: newStatus } : t))
    );
  };

  const getStatusLabel = (s: Status) =>
    s === "to-clean" ? "🔴 مطلوب تنظيف" :
    s === "in-progress" ? "🟡 قيد التنفيذ" :
    "✅ تم التنظيف";

  const statusOrder: Status[] = ["to-clean", "in-progress", "done"];

  return (
    <div style={{ display: "flex", gap: "24px", padding: "24px" }} dir="rtl">
      {statusOrder.map((status) => (
        <div key={status} style={{ flex: 1 }}>
          <h2>{getStatusLabel(status)}</h2>
          <div style={{ minHeight: "100px", background: "#f9f9f9", borderRadius: 8, padding: 8 }}>
            {tasks.filter((t) => t.status === status).map((task) => (
              <div key={task.id} style={{
                background: "#fff",
                padding: 12,
                marginBottom: 12,
                borderRadius: 8,
                boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
              }}>
                <strong>غرفة {task.roomNumber}</strong>
                <div>النزيل: {task.guestName || "غير معروف"}</div>
                <div>
                  <select
                    value={task.status}
                    onChange={(e) => updateStatus(task.id, e.target.value as Status)}
                    style={{ marginTop: 8 }}
                  >
                    {statusOrder.map((s) => (
                      <option key={s} value={s}>
                        {getStatusLabel(s)}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );

  
};

export default HousekeepingBoard;
