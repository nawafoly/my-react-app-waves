import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { NotificationService } from "../services/NotificationService";
import type { Notification } from "../types/Notification";

export default function Notifications() {
  const { user } = useAuth();
  const [list, setList] = useState<Notification[]>([]);

  useEffect(() => {
    if (user) {
      NotificationService.getNotifications(user.role, (user as any).uid || user.id)
        .then((res) => {
          if (res.ok) setList(res.data);
          else console.error(res.error);
        })
        .catch(console.error);
    }
  }, [user]);

  const handleRead = async (id: string) => {
    const res = await NotificationService.markAsRead(id);
    if (res.ok) setList(list.filter(n => n.id !== id));
    else console.error(res.error);
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h1>مركز الإشعارات</h1>
      {list.length === 0 && <p>لا توجد إشعارات جديدة.</p>}
      <ul>
        {list.map(n => (
          <li key={n.id} style={{ margin: "1rem 0", border: "1px solid #ccc", padding: "1rem" }}>
            <strong>{n.title}</strong>
            <p>{n.message}</p>
            <button onClick={() => handleRead(n.id)}>تمييز كمقروء</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
