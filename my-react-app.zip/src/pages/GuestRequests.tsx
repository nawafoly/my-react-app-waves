import React, { useMemo } from "react";
import { useAuth } from "../context/AuthContext";
import { listRequests } from "../services/RequestsService";

export default function GuestRequests() {
  const { user } = useAuth();
  const myRequests = useMemo(() => {
    if (!user) return [];
    const res = listRequests({ createdBy: user.id });
    return res.ok ? res.data : [];
  }, [user]);

  return (
    <div className="container py-8">
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">طلباتي</h1>
        <p className="text-gray-600">تتبع حالة طلباتك الأخيرة.</p>
      </header>

      <section className="card p-6">
        {myRequests.length === 0 ? (
          <div className="text-center py-4 text-gray-500">
            <p>لا توجد طلبات حالية. يمكنك تقديم طلب جديد من الصفحة الرئيسية.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="table-auto w-full">
              <thead>
                <tr className="bg-gray-100 text-gray-700 uppercase text-sm leading-normal">
                  <th className="py-3 px-6 text-left">القسم</th>
                  <th className="py-3 px-6 text-left">الحالة</th>
                  <th className="py-3 px-6 text-left">التاريخ</th>
                  <th className="py-3 px-6 text-left">ملاحظات</th>
                </tr>
              </thead>
              <tbody className="text-gray-600 text-sm font-light">
                {myRequests.map((r) => (
                  <tr key={r.id} className="border-b border-gray-200 hover:bg-gray-100">
                    <td className="py-3 px-6 text-left">{r.department}</td>
                    <td className="py-3 px-6 text-left">
                      <span className={`badge ${r.status === "completed" ? "badge-success" : r.status === "pending" ? "badge-warning" : "badge-info"}`}>
                        {r.status}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-left">{new Date(r.createdAt).toLocaleString()}</td>
                    <td className="py-3 px-6 text-left">{r.notes || "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}


