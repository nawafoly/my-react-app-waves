// src/pages/Unauthorized.tsx
import React from "react";
import { Link } from "react-router-dom";

const Unauthorized: React.FC = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.title}>🚫 غير مصرح</h1>
      <p style={styles.message}>لا تملك صلاحية الوصول إلى هذه الصفحة.</p>
      <Link to="/dashboard" style={styles.link}>
        العودة إلى الصفحة الرئيسية
      </Link>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  container: {
    textAlign: "center",
    marginTop: "80px",
    padding: "20px",
  },
  title: {
    fontSize: "32px",
    color: "#c0392b",
  },
  message: {
    fontSize: "18px",
    margin: "12px 0",
    color: "#555",
  },
  link: {
    fontSize: "16px",
    color: "#1f62ff",
    textDecoration: "underline",
  },
};

export default Unauthorized;
