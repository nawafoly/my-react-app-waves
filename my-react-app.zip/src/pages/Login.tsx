// src/pages/Login.tsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { verifyLoginLocal, seedDefaultUsersIfEmpty } from "../services/AuthService";
import { useAuth } from "../context/AuthContext";
import { getLandingPath } from "../utils/routing";
import "../styles/Login.css";

// غيّر هذا المسار إذا لوحة التحكم عندك باسم مختلف
const DASHBOARD_PATH = "/dashboard";

export default function Login() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { login, user } = useAuth();
  const isAuthenticated = !!user;

  // 1) تعبئة مستخدمين افتراضيين لو المخزن فاضي
  useEffect(() => {
    seedDefaultUsersIfEmpty();
  }, []);

  // 2) بمجرد ما يتفعّل الدخول من الـ Context، نحول تلقائيًا حسب الدور
  useEffect(() => {
    if (!isAuthenticated || !user) return;
    const target = getLandingPath(user.role);
    navigate(target, { replace: true });
  }, [isAuthenticated, user, navigate]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    const id = identifier.trim();
    const pass = password.trim();
    if (!id || !pass) return;

    setLoading(true);
    try {
      const user = await verifyLoginLocal(id, pass);

      if (!user) {
        setError("بيانات الدخول غير صحيحة. تأكد من البريد/الاسم وكلمة المرور.");
        return;
      }

      // خزّن waves_user كما هو مطلوب
      const appUser = { id: user.id, name: user.name, role: user.role } as const;
      login({
        id: appUser.id, name: appUser.name, role: appUser.role,
        email: "",
        username: "",
        passwordHash: "",
        createdAt: 0
      });
    } catch (err) {
      console.error(err);
      setError("حدث خطأ غير متوقع. جرّب لاحقًا.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleLogin} dir="rtl">
        <h2>تسجيل الدخول</h2>

        <input
          placeholder="اسم المستخدم أو البريد"
          value={identifier}
          onChange={(e) => {
            setIdentifier(e.target.value);
            if (error) setError("");
          }}
          autoComplete="username"
          required
        />

        <input
          type="password"
          placeholder="كلمة المرور"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
            if (error) setError("");
          }}
          autoComplete="current-password"
          required
        />

        <button type="submit" disabled={loading}>
          {loading ? "جاري الدخول..." : "دخول"}
        </button>

        {error && <div className="error">{error}</div>}
      </form>
    </div>
  );
}
