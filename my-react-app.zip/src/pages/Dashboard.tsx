// src/pages/Dashboard.tsx
import React, { useMemo } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { type Role } from "../services/AuthService";
import "../styles/dashboard.css";

export default function Dashboard() {
  const { user } = useAuth();
  const location = useLocation();

  if (!user)
    return (
      <div dir="rtl" style={{ padding: 20 }}>
        الرجاء تسجيل الدخول.
      </div>
    );

  const role = (user.role || "guest") as Role;

  const allPages = useMemo(() => {
    return [
      { to: "/dashboard", title: "لوحة التحكم", desc: "المركز الرئيسي" },
      { to: "/notifications", title: "الإشعارات", desc: "مركز التنبيهات" },
      { to: "/guest/home", title: "بوابة الضيف", desc: "طلب غسيل/طعام/تنظيف/صيانة" },
      { to: "/employee", title: "لوحة الموظف", desc: "مهام الموظف اليومية" },
      { to: "/supervisor", title: "لوحة المشرف", desc: "اشراف ومتابعة فرق العمل" },
      { to: "/laundry/new", title: "طلب مغسلة جديد", desc: "إنشاء طلب غسيل" },
      { to: "/laundry/orders", title: "طلبات المغسلة", desc: "قائمة وإدارة الطلبات" },
      { to: "/owner/dashboard", title: "لوحة المالك", desc: "نظرة عامة وإدارة" },
      { to: "/owner/departments", title: "الأقسام", desc: "إدارة الأقسام" },
      { to: "/owner/reports", title: "تقارير المالك", desc: "تقارير وتحليلات" },
      { to: "/owner/support", title: "دعم ومحادثات", desc: "صندوق المحادثات" },
      { to: "/owner/settings", title: "إعدادات", desc: "إعدادات عامة للنظام" },
      { to: "/create-user", title: "إنشاء مستخدم", desc: "إضافة مستخدم جديد" },
      { to: "/change-password", title: "تغيير كلمة المرور", desc: "تحديث كلمة المرور" },
      { to: "/dashboard/chat", title: "الدردشة", desc: "محادثات داخلية" },
    ];
  }, []);

  return (
    <main className="db-wrap" dir="rtl">
      <header className="db-head">
        <div>
          <h1>لوحة التحكم</h1>
        </div>
        <div className="db-user">
          <span className="tag">{roleLabel(role)}</span>
        </div>
      </header>

      <section className="db-grid">
        {/* عرض كل الروابط كبطاقات موحدة */}
        {allPages
          .filter(p => p.to !== location.pathname)
          .map(p => (
            <Card key={p.to} title={p.title} desc={p.desc}>
              <Link className="btn" to={p.to}>فتح</Link>
            </Card>
          ))}
      </section>
    </main>
  );
}

function Card({
  title,
  desc,
  children,
}: {
  title: string;
  desc: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="card">
      <h3>{title}</h3>
      <p className="muted">{desc}</p>
      {children}
    </div>
  );
}

function roleLabel(role: Role) {
  switch (role) {
    case "owner":
      return "مالك";
    case "supervisor":
      return "مشرف";
    case "employee":
      return "موظف";
    case "guest":
    default:
      return "زائر";
  }
}
