// src/pages/Home.tsx
import React from "react";
import { Link } from "react-router-dom";
import "../styles/home.css"; // استدعاء ملف التنسيق

const Home: React.FC = () => (
  <main className="home-wrap" dir="rtl">
    <section className="home-card">
      <h1 className="home-title">مرحباً بك في موقعنا</h1>
      <p className="home-sub">هذه هي الصفحة الرئيسية العامة.</p>
      <div className="home-actions">
        <Link to="/login" className="btn primary">تسجيل الدخول</Link>
        <Link to="/create-user" className="btn ghost">إنشاء حساب جديد</Link>
      </div>
    </section>
  </main>
);

export default Home;
