import React, { useState } from "react";
import ChatList from "../../components/ChatList";
import ChatWindow from "../../components/ChatWindow";
import "../../styles/Chat.css";

const OwnerChat: React.FC = () => {
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const userUid = localStorage.getItem("userUid")!;

  const handleSelect = (id: string) => setSelectedChat(id);

  return (
    <div className="dashboard-chat">
      <ChatList department="Owner" onSelectChat={handleSelect} />
      {selectedChat ? (
        <ChatWindow chatId={selectedChat} currentUserUid={userUid} />
      ) : (
        <div className="chat-placeholder">
          <p>لا توجد محادثة محددة بعد. أنشئ أو اختر محادثة!</p>
        </div>
      )}
    </div>
  );
};

export default OwnerChat;


