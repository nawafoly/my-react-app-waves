import React from "react";

export default function OwnerReports() {
  return (
    <div className="container">
      <h1 className="text-2xl font-bold mb-4">التقارير</h1>
      <p className="text-gray-600 mb-6">هنا يمكنك عرض التقارير المختلفة.</p>

      <div className="card p-6 mb-4">
        <h2 className="text-xl font-semibold mb-2">تقرير الإيرادات</h2>
        <p className="text-gray-500">ملخص الإيرادات اليومية/الشهرية/السنوية.</p>
        {/* Placeholder for a chart or table */}
        <div className="bg-gray-100 h-48 flex items-center justify-center text-gray-400 mt-4">
          مخطط أو جدول الإيرادات هنا
        </div>
      </div>

      <div className="card p-6 mb-4">
        <h2 className="text-xl font-semibold mb-2">تقرير الإشغال</h2>
        <p className="text-gray-500">نسبة إشغال الغرف.</p>
        {/* Placeholder for a chart or table */}
        <div className="bg-gray-100 h-48 flex items-center justify-center text-gray-400 mt-4">
          مخطط أو جدول الإشغال هنا
        </div>
      </div>

      <div className="card p-6">
        <h2 className="text-xl font-semibold mb-2">تقرير الغسيل</h2>
        <p className="text-gray-500">ملخص خدمات الغسيل.</p>
        {/* Placeholder for a chart or table */}
        <div className="bg-gray-100 h-48 flex items-center justify-center text-gray-400 mt-4">
          مخطط أو جدول الغسيل هنا
        </div>
      </div>
    </div>
  );
}


