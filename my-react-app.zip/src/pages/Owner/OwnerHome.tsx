// src/pages/Owner/OwnerHome.tsx
import React from "react";

const OwnerHome: React.FC = () => {
  return (
    <div>
      <h1>لوحة المالك - الصفحة الرئيسية</h1>
      <p>هذا هو المحتوى الافتراضي لصفحة /owner</p>
    </div>
  );
};

export default OwnerHome;
