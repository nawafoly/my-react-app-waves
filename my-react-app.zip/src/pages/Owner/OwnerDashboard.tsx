import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

export default function OwnerDashboard() {
  const { user } = useAuth();

  return (
    <div className="container">
      <h1 className="text-2xl font-bold mb-4">مرحباً بك، {user?.name || "المالك"}!</h1>
      <p className="text-gray-600 mb-6">هذه لوحة التحكم الخاصة بك. يمكنك إدارة جميع جوانب الفندق من هنا.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">إدارة المستخدمين</h2>
          <p className="text-gray-500 mb-4">إضافة، تعديل، وحذف المستخدمين.</p>
          <Link to="/owner/users" className="btn btn-primary">إدارة المستخدمين</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">إدارة الأقسام</h2>
          <p className="text-gray-500 mb-4">عرض وإدارة أقسام الفندق.</p>
          <Link to="/owner/departments" className="btn btn-primary">إدارة الأقسام</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">التقارير</h2>
          <p className="text-gray-500 mb-4">عرض التقارير المالية والتشغيلية.</p>
          <Link to="/owner/reports" className="btn btn-primary">عرض التقارير</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">الإعدادات</h2>
          <p className="text-gray-500 mb-4">تكوين إعدادات الفندق العامة.</p>
          <Link to="/owner/settings" className="btn btn-primary">تعديل الإعدادات</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">الدعم والدردشة</h2>
          <p className="text-gray-500 mb-4">التواصل مع فريق الدعم أو الموظفين.</p>
          <Link to="/owner/support" className="btn btn-primary">فتح الدردشة</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">إدارة الغسيل</h2>
          <p className="text-gray-500 mb-4">مراقبة وإدارة عمليات الغسيل.</p>
          <Link to="/laundry/orders" className="btn btn-primary">إدارة الغسيل</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">إدارة التدبير المنزلي</h2>
          <p className="text-gray-500 mb-4">مراقبة وإدارة مهام التدبير المنزلي.</p>
          <Link to="/housekeeping" className="btn btn-primary">إدارة التدبير المنزلي</Link>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-2">إدارة خدمة الغرف</h2>
          <p className="text-gray-500 mb-4">مراقبة وإدارة طلبات خدمة الغرف.</p>
          <Link to="/room-service/menu" className="btn btn-primary">إدارة خدمة الغرف</Link>
        </div>
      </div>
    </div>
  );
}


