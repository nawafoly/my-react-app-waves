// src/pages/Owner/OwnerUsers.tsx
import React, { useEffect, useState } from "react";
import { PERMS, Perm, WavesUser, readUsers, writeUsers } from "../../services/AuthService";
export { readUsers, writeUsers } from "../../services/AuthService";
import "../../styles/tables.css";
import "../../styles/create-user.css"; // لإعادة استخدام تنسيق cu-btn

const OwnerUsers: React.FC = () => {
  const [users, setUsers] = useState<WavesUser[]>([]);

  useEffect(() => {
    const list = readUsers();
    setUsers(list);
  }, []);

  const toggleForcePassword = (id: string) => {
    const updated = users.map((u) =>
      u.id === id ? { ...u, mustChangePassword: !u.mustChangePassword } : u
    );
    setUsers(updated);
    writeUsers(updated);
  };

  const disableUser = (id: string) => {
    const filtered = users.filter((u) => u.id !== id);
    setUsers(filtered);
    writeUsers(filtered);
  };

  return (
    <div className="page-content">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>إدارة المستخدمين</h2>
        <a href="/create-user" className="cu-btn" style={{ textDecoration: "none" }}>
          + إضافة مستخدم
        </a>
      </div>

      <table className="table" style={{ marginTop: "16px" }}>
        <thead>
          <tr>
            <th>الاسم</th>
            <th>الدور</th>
            <th>القسم</th>
            <th>الصلاحيات</th>
            <th>مطلوب تغيير كلمة المرور؟</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td>{u.name}</td>
              <td>{u.role}</td>
              <td>{u.dept ?? "-"}</td>
              <td>
                <ul>
                  {(u.perms ?? []).map((p: Perm) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              </td>
              <td>{u.mustChangePassword ? "نعم" : "لا"}</td>
              <td>
                <button onClick={() => toggleForcePassword(u.id)}>
                  إجبار تغيير كلمة المرور
                </button>
                <button onClick={() => disableUser(u.id)} style={{ marginRight: 8 }}>
                  تعطيل / حذف
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OwnerUsers;
