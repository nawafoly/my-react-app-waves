// src/pages/owner/OwnerDepartments.tsx
import React from "react";

type Department = {
  id: string;
  name: string;
  activeEmployees: number;
  pendingRequests: number;
};

const mockDepartments: Department[] = [
  { id: "laundry", name: "المغسلة", activeEmployees: 4, pendingRequests: 2 },
  { id: "housekeeping", name: "الهاوسكيبنق", activeEmployees: 6, pendingRequests: 1 },
  { id: "kitchen", name: "المطبخ", activeEmployees: 3, pendingRequests: 0 },
  { id: "maintenance", name: "الصيانة", activeEmployees: 2, pendingRequests: 1 },
  { id: "reception", name: "الاستقبال", activeEmployees: 5, pendingRequests: 0 },
];

const OwnerDepartments: React.FC = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1 style={{ fontSize: "1.8rem", fontWeight: "bold" }}>إدارة الأقسام</h1>
      <p style={{ marginTop: "0.5rem", color: "#555" }}>
        نظرة سريعة على الأقسام، عدد الموظفين النشطين، والطلبات المعلقة.
      </p>

      <div style={{ marginTop: "1.5rem", display: "grid", gap: "1rem", gridTemplateColumns: "repeat(auto-fit,minmax(250px,1fr))" }}>
        {mockDepartments.map((d) => (
          <div
            key={d.id}
            style={{
              background: "white",
              borderRadius: "12px",
              padding: "16px",
              boxShadow: "0 8px 24px rgba(0,0,0,0.04)",
              position: "relative",
            }}
          >
            <h2 style={{ margin: 0, fontSize: "1.2rem" }}>{d.name}</h2>
            <div style={{ marginTop: "8px", fontSize: "0.9rem" }}>
              <div>الموظفين النشطين: <strong>{d.activeEmployees}</strong></div>
              <div>الطلبات المعلقة: <strong>{d.pendingRequests}</strong></div>
            </div>
            <button
              style={{
                marginTop: "12px",
                padding: "8px 14px",
                backgroundColor: "#006a91",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: "500",
              }}
            >
              عرض التفاصيل
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OwnerDepartments;
