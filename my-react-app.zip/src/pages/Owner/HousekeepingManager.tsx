import React, { useState, useEffect } from "react";

type Status = "dirty" | "in-progress" | "clean";

interface Room {
  id: number;
  status: Status;
  note: string;
}

const STORAGE_KEY = "hk_rooms";

const defaultRooms: Room[] = [
  { id: 101, status: "dirty", note: "" },
  { id: 102, status: "dirty", note: "" },
  { id: 103, status: "clean", note: "" }
];

const HousekeepingManager: React.FC = () => {
  const [rooms, setRooms] = useState<Room[]>([
  { id: 101, status: "dirty", note: "مناشف ناقصة" },
  { id: 102, status: "in-progress", note: "يوجد زبون داخل الغرفة" },
  { id: 103, status: "clean", note: "تم التنظيف بالكامل" },
  { id: 104, status: "dirty", note: "" },
]);
  const [newRoomNumber, setNewRoomNumber] = useState("");

  // التحميل من localStorage
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) setRooms(JSON.parse(saved));
  }, []);

  // الحفظ التلقائي
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rooms));
  }, [rooms]);

  const cycleStatus = (r: Room) => {
    const next: Status =
      r.status === "dirty" ? "in-progress" : r.status === "in-progress" ? "clean" : "dirty";
    updateRoom(r.id, { status: next });
  };

  const updateRoom = (id: number, changes: Partial<Room>) => {
    setRooms(prev => prev.map(r => (r.id === id ? { ...r, ...changes } : r)));
  };

  const addRoom = () => {
    const id = parseInt(newRoomNumber);
    if (!id || rooms.some(r => r.id === id)) return;
    setRooms(prev => [...prev, { id, status: "dirty", note: "" }]);
    setNewRoomNumber("");
  };

  return (
    <div className="hk-wrap" dir="rtl">
      <h1>إدارة النظافة</h1>
      <div>
        <input
          type="number"
          value={newRoomNumber}
          onChange={e => setNewRoomNumber(e.target.value)}
          placeholder="رقم الغرفة"
        />
        <button onClick={addRoom}>+ إضافة غرفة</button>
      </div>
      <div className="hk-grid">
        {rooms.map(r => (
          <div key={r.id} className={`hk-card hk-${r.status}`}>
            <h3>غرفة {r.id}</h3>
            <p>
              الحالة: {r.status}
            </p>
            <button onClick={() => cycleStatus(r)}>تغيير الحالة</button>
            <textarea
              value={r.note}
              onChange={e => updateRoom(r.id, { note: e.target.value })}
              placeholder="ملاحظات..."
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default HousekeepingManager;
