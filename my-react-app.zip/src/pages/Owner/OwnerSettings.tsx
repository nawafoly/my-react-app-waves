import React, { useState } from "react";

export default function OwnerSettings() {
  const [hotelName, setHotelName] = useState("Waves Hotel");
  const [taxRate, setTaxRate] = useState(15);
  const [currency, setCurrency] = useState("SAR");
  const [theme, setTheme] = useState("light");

  const handleSave = () => {
    // Logic to save settings (e.g., to localStorage or backend)
    console.log("Saving settings:", { hotelName, taxRate, currency, theme });
    alert("تم حفظ الإعدادات بنجاح!");
  };

  return (
    <div className="container">
      <h1 className="text-2xl font-bold mb-4">الإعدادات</h1>
      <p className="text-gray-600 mb-6">إدارة إعدادات الفندق العامة.</p>

      <div className="card p-6 mb-4">
        <h2 className="text-xl font-semibold mb-2">إعدادات الفندق</h2>
        <div className="form-group mb-4">
          <label htmlFor="hotelName" className="form-label">اسم الفندق:</label>
          <input
            type="text"
            id="hotelName"
            className="form-control"
            value={hotelName}
            onChange={(e) => setHotelName(e.target.value)}
          />
        </div>
        <div className="form-group mb-4">
          <label htmlFor="taxRate" className="form-label">نسبة الضريبة (%):</label>
          <input
            type="number"
            id="taxRate"
            className="form-control"
            value={taxRate}
            onChange={(e) => setTaxRate(parseFloat(e.target.value))}
          />
        </div>
        <div className="form-group mb-4">
          <label htmlFor="currency" className="form-label">العملة:</label>
          <input
            type="text"
            id="currency"
            className="form-control"
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
          />
        </div>
        <div className="form-group mb-4">
          <label htmlFor="theme" className="form-label">السمة:</label>
          <select
            id="theme"
            className="form-control"
            value={theme}
            onChange={(e) => setTheme(e.target.value)}
          >
            <option value="light">فاتح</option>
            <option value="dark">داكن</option>
          </select>
        </div>
        <button onClick={handleSave} className="btn btn-primary">حفظ الإعدادات</button>
      </div>

      <div className="card p-6">
        <h2 className="text-xl font-semibold mb-2">إدارة الكتالوج</h2>
        <p className="text-gray-500 mb-4">إدارة عناصر قائمة خدمة الغرف، عناصر الغسيل، وغيرها.</p>
        <button className="btn btn-secondary">إدارة الكتالوج</button>
      </div>
    </div>
  );
}


