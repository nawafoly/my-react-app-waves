// src/pages/CreateUserInternal.tsx
import React, { useState } from "react";
import { registerUser, Role } from "../services/userSetup";

export default function CreateUserInternal() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<Role>("employee");
  const [department, setDepartment] = useState<string>("laundry");
  const [msg, setMsg] = useState("");

  const handleCreate = async () => {
    try {
      const uid = await registerUser({ email, password, name, role, department });
      setMsg(`تم الإنشاء (UID: ${uid})`);
    } catch (e: any) {
      setMsg("خطأ: " + e.message);
    }
  };

  return (
    <div style={{ padding: 24, maxWidth: 500, margin: "auto" }}>
      {/* نموذج الإدخال كما سبق */}
    </div>
  );
}
