import { Role } from "firebase/ai";

export interface Notification {
  id: string;
  title: string;
  message: string;
  createdAt: Date;
  read: boolean;
  targetRole?: Role;       // مثلاً «employee»، «supervisor»، أو بدون هذا الحقل يعني للجميع
  targetUid?: string;      // أو مخصّصة لمستخدم معيّن
}
