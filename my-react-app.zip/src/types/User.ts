// src/types/User.ts

import { Role } from "firebase/ai";
import { Department } from "../services/AuthService";

// Re-export the canonical types from AuthService (بدون تعريفات مكررة)
export type { Role, Department, WavesUser, Perm } from "../services/AuthService";

// (اختياري) نوع للاستخدام في فورم إنشاء مستخدم
export type CreateUserInput = {
  name: string;
  email: string;
  username: string;
  role: Role;
  dept?: Department;
  password?: string;
  mustChangePassword?: boolean;
};

// (اختياري) لو تحتاج واجهة خفيفة داخل الواجهة، سَمِّها اسمًا مختلفًا
export interface AppUserLite {
  id?: string;
  name: string;
  email: string;
  role: Role;
  department?: Department;
  createdAt?: number; // ملاحظة: WavesUser يستخدم number (timestamp) وليس Date
}
