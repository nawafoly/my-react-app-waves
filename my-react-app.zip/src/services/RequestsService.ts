import type { ApiResult } from "./types";
import { NotificationService } from "./NotificationService";

export type RequestStatus = "NEW" | "IN_PROGRESS" | "DONE" | "CANCELLED";
export type Department = "laundry" | "room-service" | "maintenance" | "housekeeping";

export interface BaseRequest {
    id: string;
    createdAt: number;
    createdBy: string; // user id
    roomNumber?: string;
    department: Department;
    status: RequestStatus;
    notes?: string;
}

export interface LaundryRequest extends BaseRequest {
    department: "laundry";
    items: { itemId: string; qty: number }[];
}

export interface RoomServiceOrder extends BaseRequest {
    department: "room-service";
    items: { name: string; qty: number; price?: number }[];
}

export interface MaintenanceTicket extends BaseRequest {
    department: "maintenance";
    details: string;
}

export interface HousekeepingRequest extends BaseRequest {
    department: "housekeeping";
    details: string;
}

export type AnyRequest =
    | LaundryRequest
    | RoomServiceOrder
    | MaintenanceTicket
    | HousekeepingRequest;

const LS_KEY = "waves_requests";

function readAll(): AnyRequest[] {
    try {
        const raw = localStorage.getItem(LS_KEY);
        return raw ? (JSON.parse(raw) as AnyRequest[]) : [];
    } catch {
        return [];
    }
}

function writeAll(list: AnyRequest[]) {
    localStorage.setItem(LS_KEY, JSON.stringify(list));
}

export function createRequest<T extends AnyRequest>(data: Omit<T, "id" | "createdAt" | "status">): ApiResult<T> {
    try {
        const req = { ...data, id: crypto.randomUUID(), createdAt: Date.now(), status: "NEW" } as T;
        const all = readAll();
        all.push(req);
        writeAll(all);
        // mock notification
        NotificationService.sendNotification({
            title: `طلب جديد: ${req.department}`,
            message: `طلب من المستخدم ${req.createdBy}`,
            targetRole: req.department === "laundry" || req.department === "room-service" ? "employee" : "supervisor",
        } as any);
        return { ok: true, data: req };
    } catch (e: any) {
        return { ok: false, error: e?.message || "Failed to create request" };
    }
}

export function listRequests(filter?: {
    department?: Department;
    createdBy?: string;
    status?: RequestStatus;
}): ApiResult<AnyRequest[]> {
    try {
        let data = readAll();
        if (filter?.department) data = data.filter((r) => r.department === filter.department);
        if (filter?.createdBy) data = data.filter((r) => r.createdBy === filter.createdBy);
        if (filter?.status) data = data.filter((r) => r.status === filter.status);
        data = data.sort((a, b) => b.createdAt - a.createdAt);
        return { ok: true, data };
    } catch (e: any) {
        return { ok: false, error: e?.message || "Failed to list requests" };
    }
}

export function getRequest(id: string): ApiResult<AnyRequest | undefined> {
    try {
        const data = readAll().find((r) => r.id === id);
        return { ok: true, data };
    } catch (e: any) {
        return { ok: false, error: e?.message || "Failed to get request" };
    }
}

export function updateRequestStatus(id: string, status: RequestStatus): ApiResult<AnyRequest> {
    try {
        const all = readAll();
        const idx = all.findIndex((r) => r.id === id);
        if (idx === -1) return { ok: false, error: "Request not found" };
        all[idx] = { ...all[idx], status } as AnyRequest;
        writeAll(all);
        NotificationService.sendNotification({
            title: `تحديث حالة الطلب`,
            message: `تم تحديث الحالة إلى ${status}`,
            targetRole: null,
        } as any);
        return { ok: true, data: all[idx] };
    } catch (e: any) {
        return { ok: false, error: e?.message || "Failed to update request" };
    }
}


