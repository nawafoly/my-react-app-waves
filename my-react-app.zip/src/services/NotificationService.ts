// src/services/NotificationService.ts
import { db } from "../firebase/firebase";
import { collection, query, where, orderBy, addDoc, getDocs, updateDoc, doc } from "firebase/firestore";
import type { Notification } from "../types/Notification";
import type { ApiResult } from "./types";

export class NotificationService {
  static collectionName = "notifications";

  // جلب الإشعارات للـ user الحالي أو لدوره
  static async getNotifications(role: string, uid: string): Promise<ApiResult<Notification[]>> {
    try {
      const q = query(
        collection(db, this.collectionName),
        where("read", "==", false),
        where("targetRole", "in", [role, null]),
        orderBy("createdAt", "desc")
      );
      const snap = await getDocs(q);
      const data = snap.docs.map(d => ({ id: d.id, ...(d.data() as any) } as Notification));
      return { ok: true, data };
    } catch (e: any) {
      return { ok: false, error: e?.message || "Failed to fetch notifications" };
    }
  }

  // وضع إشعار جديد
  static async sendNotification(payload: Omit<Notification, "id" | "createdAt" | "read">): Promise<ApiResult<null>> {
    try {
      await addDoc(collection(db, this.collectionName), {
        ...payload,
        read: false,
        createdAt: new Date(),
      });
      return { ok: true, data: null };
    } catch (e: any) {
      return { ok: false, error: e?.message || "Failed to send notification" };
    }
  }

  // تعليم إشعار كمقروء
  static async markAsRead(id: string): Promise<ApiResult<null>> {
    try {
      const ref = doc(db, this.collectionName, id);
      await updateDoc(ref, { read: true });
      return { ok: true, data: null };
    } catch (e: any) {
      return { ok: false, error: e?.message || "Failed to mark as read" };
    }
  }
}
