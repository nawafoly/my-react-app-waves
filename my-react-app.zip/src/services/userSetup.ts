// src/services/userSetup.ts
import { createUserWithEmailAndPassword } from "firebase/auth";
import { setDoc, doc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../firebase/firebase";

export type Role = "owner" | "supervisor" | "employee" | "guest";

export interface NewUserPayload {
  email: string;
  password: string;
  name: string;
  role: Role;
  department?: string | null; // مثلاً "laundry", "housekeeping"
}

/**
 * ينشئ مستخدم في Firebase Auth ثم يكتب بياناته في Firestore
 */
export async function registerUser(payload: NewUserPayload) {
  const { email, password, name, role, department = null } = payload;

  try {
    // 1. إنشاء حساب في Auth
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const uid = userCredential.user.uid;

    // 2. حفظ البيانات في Firestore تحت مجموعة users
    await setDoc(doc(db, "users", uid), {
      name,
      email,
      role,
      department: role === "owner" ? null : department,
      createdAt: serverTimestamp(), // يُملأ تلقائيًا بتوقيت السيرفر
    });

    return uid;
  } catch (error) {
    console.error("Failed to register user:", error);
    throw error;
  }
}
