// src/services/LaundryService.ts
export type LaundryItem = {
  id: string;
  nameAr: string;
  nameEn: string;
  price: number; // SAR
};

export type LaundryOrderItem = {
  itemId: string;
  qty: number;
};

export type LaundryOrder = {
  id: string;
  roomNumber: string;
  items: LaundryOrderItem[];
  subtotal: number;  // قبل الضريبة
  vat: number;       // 15%
  total: number;     // بعد الضريبة
  status: "received" | "washing" | "ironing" | "ready" | "delivered" | "canceled";
  notes?: string;
  createdAt: number;
  updatedAt: number;
};

import type { ApiResult } from "./types";

const VAT_RATE = 0.15;
const LS_ITEMS = "laundry_items";
const LS_ORDERS = "laundry_orders";

export const laundryItems: LaundryItem[] = [
  { id: "bisht",   nameAr: "بشت",                 nameEn: "Bisht",               price: 15 },
  { id: "trouser", nameAr: "بنطال / جينز",        nameEn: "Trouser / Jeans",     price: 15 },
  { id: "skirt",   nameAr: "تنورة / وسط",         nameEn: "Skirt / Waist",       price: 15 },
  { id: "overcoat",nameAr: "معطف",                nameEn: "Overcoat",            price: 22 },
  { id: "pajamas", nameAr: "بيجامة",              nameEn: "Pajamas",             price: 22 },
  { id: "thobe",   nameAr: "ثوب",                 nameEn: "Thobe",               price: 23 },
  // كمّل بقية القائمة لاحقًا من الورقة
];

// حفظ القائمة مرة واحدة لو ودك:
if (!localStorage.getItem(LS_ITEMS)) {
  localStorage.setItem(LS_ITEMS, JSON.stringify(laundryItems));
}

function readOrders(): LaundryOrder[] {
  const raw = localStorage.getItem(LS_ORDERS);
  return raw ? JSON.parse(raw) : [];
}
function writeOrders(orders: LaundryOrder[]) {
  localStorage.setItem(LS_ORDERS, JSON.stringify(orders));
}

export function calcTotals(items: LaundryOrderItem[], allItems: LaundryItem[] = laundryItems) {
  const subtotal = items.reduce((sum, it) => {
    const meta = allItems.find(x => x.id === it.itemId);
    return sum + (meta ? meta.price * it.qty : 0);
  }, 0);
  const vat = +(subtotal * VAT_RATE).toFixed(2);
  const total = +(subtotal + vat).toFixed(2);
  return { subtotal, vat, total };
}

export function createOrder(data: { roomNumber: string; items: LaundryOrderItem[]; notes?: string }): ApiResult<LaundryOrder> {
  try {
    const now = Date.now();
    const { subtotal, vat, total } = calcTotals(data.items);
    const order: LaundryOrder = {
      id: crypto.randomUUID(),
      roomNumber: data.roomNumber.trim(),
      items: data.items,
      subtotal, vat, total,
      status: "received",
      notes: data.notes,
      createdAt: now,
      updatedAt: now,
    };
    const orders = readOrders();
    orders.push(order);
    writeOrders(orders);
    return { ok: true, data: order };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to create order" };
  }
}

export function listOrders(): ApiResult<LaundryOrder[]> {
  try {
    return { ok: true, data: readOrders().sort((a,b) => b.createdAt - a.createdAt) };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to list orders" };
  }
}

export function getOrder(id: string): ApiResult<LaundryOrder | undefined> {
  try {
    return { ok: true, data: readOrders().find(o => o.id === id) };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to get order" };
  }
}

export function updateOrderStatus(id: string, status: LaundryOrder["status"]): ApiResult<LaundryOrder> {
  try {
    const orders = readOrders();
    const i = orders.findIndex(o => o.id === id);
    if (i === -1) return { ok: false, error: "الطلب غير موجود" };
    orders[i] = { ...orders[i], status, updatedAt: Date.now() };
    writeOrders(orders);
    return { ok: true, data: orders[i] };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to update order" };
  }
}

export function deleteOrder(id: string): ApiResult<null> {
  try {
    const orders = readOrders().filter(o => o.id !== id);
    writeOrders(orders);
    return { ok: true, data: null };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to delete order" };
  }
}
