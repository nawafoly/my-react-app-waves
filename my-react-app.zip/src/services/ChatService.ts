import { db } from "../firebase/firebase";
import {
  collection,
  doc,
  addDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  getDocs,
  where,
  DocumentData,
  Timestamp,
} from "firebase/firestore";

import type { ApiResult } from "./types";

export interface Message {
  id: string;
  senderUid: string;
  text: string;
  createdAt: Date;
}

export interface ChatRoom {
  id: string;
  department?: string;
  participants: string[];
  lastUpdated: Timestamp;
}

export class ChatService {
  static chatsColl = () => collection(db, "chats");
  static messagesColl = (chatId: string) =>
    collection(db, "chats", chatId, "messages");

  /** أنشئ غرفة دردشة */
  static async createChat(department: string | null, participants: string[]): Promise<ApiResult<string>> {
    try {
      const data: any = { participants, lastUpdated: serverTimestamp() };
      if (department) data.department = department;
      const docRef = await addDoc(this.chatsColl(), data);
      return { ok: true, data: docRef.id };
    } catch (e: any) {
      return { ok: false, error: e?.message || "Failed to create chat" };
    }
  }

  /** أرسل رسالة */
  static async sendMessage(chatId: string, senderUid: string, text: string): Promise<ApiResult<null>> {
    try {
      const messagesRef = this.messagesColl(chatId);
      await addDoc(messagesRef, { senderUid, text, createdAt: serverTimestamp() });
      const chatRef = doc(db, "chats", chatId);
      await updateDoc(chatRef, { lastUpdated: serverTimestamp() });
      return { ok: true, data: null };
    } catch (e: any) {
      return { ok: false, error: e?.message || "Failed to send message" };
    }
  }

  /** اشترك في تحديثات الرسائل */
  static subscribeToMessages(
    chatId: string,
    onUpdate: (msgs: Message[]) => void
  ) {
    const q = query(this.messagesColl(chatId), orderBy("createdAt", "asc"));
    return onSnapshot(q, (snap) => {
      const msgs: Message[] = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as any),
        createdAt: (d.data() as any).createdAt.toDate(),
      }));
      onUpdate(msgs);
    });
  }

  /** جلب شاتات القسم */
  static async getChatsForDepartment(department: string): Promise<ApiResult<ChatRoom[]>> {
    try {
      const q = query(
        this.chatsColl(),
        where("department", "==", department),
        orderBy("lastUpdated", "desc")
      );
      const snap = await getDocs(q);
      const data = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      return { ok: true, data };
    } catch (e: any) {
      return { ok: false, error: e?.message || "Failed to fetch chats" };
    }
  }

  /** جلب كل الغرف */
  static async getAllChats(): Promise<ApiResult<ChatRoom[]>> {
    try {
      const q = query(this.chatsColl(), orderBy("lastUpdated", "desc"));
      const snap = await getDocs(q);
      const data = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      return { ok: true, data };
    } catch (e: any) {
      return { ok: false, error: e?.message || "Failed to fetch chats" };
    }
  }

  /** جلب كل المستخدمين */
  static async getAllUsers(): Promise<ApiResult<{ uid: string; displayName?: string }[]>> {
    try {
      const q = collection(db, "users");
      const snap = await getDocs(q);
      const data = snap.docs
        .map((d) => ({ uid: d.id, ...(d.data() as any) }))
        .filter((u) => u.uid !== localStorage.getItem("userUid"));
      return { ok: true, data };
    } catch (e: any) {
      return { ok: false, error: e?.message || "Failed to fetch users" };
    }
  }
}
