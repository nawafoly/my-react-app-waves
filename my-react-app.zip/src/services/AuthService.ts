// src/services/AuthService.ts
/** Roles */
export type Role = "owner" | "supervisor" | "employee" | "guest";

/** Departments */
export type Department = "laundry" | "kitchen" | "housekeeping" | "frontdesk";

/** User model */
export type WavesUser = {
  id: string;
  name: string;
  email: string;           // lowercase + trimmed
  role: Role;
  username: string;        // lowercase + trimmed
  passwordHash: string;    // SHA-256
  mustChangePassword?: boolean;
  createdAt: number;

  /** OPTIONAL */
  dept?: Department;       // employee’s department
  perms?: Perm[];          // manual extra perms
};

const LS_KEY = "waves_users";

/* ---------- Permissions ---------- */
export const PERMS = {
  LAUNDRY_VIEW: "laundry.view",
  LAUNDRY_MANAGE: "laundry.manage",

  KITCHEN_VIEW: "kitchen.view",
  KITCHEN_MANAGE: "kitchen.manage",

  HK_VIEW: "housekeeping.view",
  HK_MANAGE: "housekeeping.manage",

  FRONTDESK_VIEW: "frontdesk.view",
  FRONTDESK_MANAGE: "frontdesk.manage",

  REPORTS_VIEW: "reports.view",
  USERS_MANAGE: "users.manage",
} as const;

export type Perm = typeof PERMS[keyof typeof PERMS];

/** Role default perms */
export const ROLE_PERMISSIONS: Record<Role, Perm[]> = {
  owner: [
    PERMS.LAUNDRY_VIEW, PERMS.LAUNDRY_MANAGE,
    PERMS.KITCHEN_VIEW, PERMS.KITCHEN_MANAGE,
    PERMS.HK_VIEW, PERMS.HK_MANAGE,
    PERMS.FRONTDESK_VIEW, PERMS.FRONTDESK_MANAGE,
    PERMS.REPORTS_VIEW, PERMS.USERS_MANAGE,
  ],
  supervisor: [
    PERMS.LAUNDRY_VIEW, PERMS.LAUNDRY_MANAGE,
    PERMS.REPORTS_VIEW,
  ],
  employee: [
    // employees get perms from their department (see DEPT_PERMISSIONS)
  ],
  guest: [
    PERMS.LAUNDRY_VIEW,
  ],
};

/** Department perms */
export const DEPT_PERMISSIONS: Record<Department, Perm[]> = {
  laundry: [PERMS.LAUNDRY_VIEW, PERMS.LAUNDRY_MANAGE],
  kitchen: [PERMS.KITCHEN_VIEW, PERMS.KITCHEN_MANAGE],
  housekeeping: [PERMS.HK_VIEW, PERMS.HK_MANAGE],
  frontdesk: [PERMS.FRONTDESK_VIEW, PERMS.FRONTDESK_MANAGE],
};

/** Merge role + dept + extra perms */
export function getUserPerms(u: Pick<WavesUser, "role" | "dept" | "perms">): Set<Perm> {
  const merged = new Set<Perm>(ROLE_PERMISSIONS[u.role] ?? []);
  if (u.dept) (DEPT_PERMISSIONS[u.dept] ?? []).forEach(p => merged.add(p));
  (u.perms ?? []).forEach(p => merged.add(p));
  return merged;
}

/** userHas can accept Role (legacy) or User (new) */
export function userHas(subject: Role | Pick<WavesUser, "role" | "dept" | "perms">, perm: Perm) {
  if (typeof subject === "string") {
    return (ROLE_PERMISSIONS[subject] ?? []).includes(perm);
  }
  return getUserPerms(subject).has(perm);
}

/* ---------- Local storage helpers ---------- */
function safeParse<T>(raw: string | null, fallback: T): T {
  try { return raw ? (JSON.parse(raw) as T) : fallback; } catch { return fallback; }
}

export function readUsers(): WavesUser[] {
  return safeParse<WavesUser[]>(localStorage.getItem(LS_KEY), []);
}

export function writeUsers(users: WavesUser[]) {
  localStorage.setItem(LS_KEY, JSON.stringify(users));
}


/* ---------- utils ---------- */
export async function sha256(text: string): Promise<string> {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  const arr = Array.from(new Uint8Array(buf));
  return arr.map((b) => b.toString(16).padStart(2, "0")).join("");
}

function norm(s: string) {
  return (s ?? "").trim().toLowerCase();
}

export function generateTempPassword(len = 8): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

/* ---------- create user ---------- */
export async function createUserLocal(data: {
  name: string;
  email: string;
  role: Role;
  username: string;
  password?: string;
  mustChangePassword?: boolean;
  dept?: Department;   // NEW
  perms?: Perm[];      // NEW
}): Promise<{ user: WavesUser; tempPassword?: string }> {
  const users = readUsers();

  const username = norm(data.username);
  const email = norm(data.email);

  if (users.some((u) => u.username === username)) throw new Error("اسم المستخدم موجود مسبقًا");
  if (users.some((u) => u.email === email)) throw new Error("البريد الإلكتروني مستخدم مسبقًا");

  const tempPassword = data.password?.trim() || generateTempPassword();
  const passwordHash = await sha256(tempPassword);
  const mustChange =
    typeof data.mustChangePassword === "boolean" ? data.mustChangePassword : !data.password;

  const user: WavesUser = {
    id: crypto.randomUUID(),
    name: data.name,
    email,
    role: data.role,
    username,
    passwordHash,
    mustChangePassword: mustChange,
    createdAt: Date.now(),
    dept: data.dept,
    perms: data.perms ?? [],
  };

  users.push(user);
  writeUsers(users);

  return { user, tempPassword: !data.password ? tempPassword : undefined };
}

/* ---------- password ---------- */
export async function updatePasswordLocal(userId: string, newPassword: string): Promise<void> {
  const users = readUsers();
  const i = users.findIndex((u) => u.id === userId);
  if (i === -1) throw new Error("المستخدم غير موجود");
  users[i].passwordHash = await sha256(newPassword.trim());
  users[i].mustChangePassword = false;
  writeUsers(users);
}

/* ---------- login ---------- */
export async function verifyLoginLocal(identifier: string, password: string) {
  const users = readUsers();
  const id = norm(identifier);
  const user = users.find((u) => u.username === id || u.email === id);
  if (!user) return null;
  const hash = await sha256(password.trim());
  return user.passwordHash === hash ? user : null;
}

/* ---------- seed ---------- */
export async function seedDefaultUsersIfEmpty() {
  const users = readUsers();
  if (users.length > 0) return;

  const ownerPass = "123456";
  const superPass = "123456";
  const [ownerHash, superHash] = await Promise.all([sha256(ownerPass), sha256(superPass)]);
  const now = Date.now();

  const seed: WavesUser[] = [
    {
      id: crypto.randomUUID(),
      name: "Owner",
      email: norm("owner@hotel.com"),
      role: "owner",
      username: norm("owner@hotel.com"),
      passwordHash: ownerHash,
      mustChangePassword: false,
      createdAt: now,
    },
    {
      id: crypto.randomUUID(),
      name: "Supervisor",
      email: norm("super@hotel.com"),
      role: "supervisor",
      username: norm("super@hotel.com"),
      passwordHash: superHash,
      mustChangePassword: false,
      createdAt: now,
    },
  ];

  writeUsers(seed);
}
