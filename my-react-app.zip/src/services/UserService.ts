// src/services/UserService.ts
import { db } from "../firebase/firebase";
import { collection, addDoc, getDocs, doc, updateDoc, deleteDoc } from "firebase/firestore";
import { User } from "../types/User";
import type { ApiResult } from "./types";

// دالة إضافة مستخدم
export const createUser = async (user: User): Promise<ApiResult<string>> => {
  try {
    const docRef = await addDoc(collection(db, "users"), {
      ...user,
      createdAt: new Date(),
    });
    return { ok: true, data: docRef.id };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to create user" };
  }
};

// جلب كل المستخدمين
export const getAllUsers = async (): Promise<ApiResult<User[]>> => {
  try {
    const snapshot = await getDocs(collection(db, "users"));
    const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as User));
    return { ok: true, data };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to fetch users" };
  }
};

// تحديث مستخدم
export const updateUser = async (id: string, user: Partial<User>): Promise<ApiResult<null>> => {
  try {
    const docRef = doc(db, "users", id);
    await updateDoc(docRef, user);
    return { ok: true, data: null };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to update user" };
  }
};

// حذف مستخدم
export const deleteUser = async (id: string): Promise<ApiResult<null>> => {
  try {
    const docRef = doc(db, "users", id);
    await deleteDoc(docRef);
    return { ok: true, data: null };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Failed to delete user" };
  }
};
