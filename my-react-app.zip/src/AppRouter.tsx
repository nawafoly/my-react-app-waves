import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import OwnerLayout from "./layouts/OwnerLayout";
import { getLandingPath } from "./utils/routing";
import {
  DEPT_PERMISSIONS,
  Perm,
  PERMS,
  ROLE_PERMISSIONS,
  WavesUser,
} from "./services/AuthService";

// صفحات عامة
import Home from "./pages/Home";
import Login from "./pages/Login";
import CreateUser from "./pages/CreateUser";
import SetupOwner from "./pages/SetupOwner";
import Unauthorized from "./pages/Unauthorized";

// الضيوف
import GuestHome from "./pages/GuestHome";
import GuestRequests from "./pages/GuestRequests";
import GuestHousekeeping from "./pages/GuestHousekeeping";
import GuestMaintenance from "./pages/GuestMaintenance";

// الموظفين
import EmployeeDashboard from "./pages/EmployeeDashboard";
import SupervisorDashboard from "./pages/SupervisorDashboard";
import ChangePassword from "./pages/ChangePassword";
import Dashboard from "./pages/Dashboard";

// المالك
import OwnerHome from "./pages/Owner/OwnerHome";
import OwnerDepartments from "./pages/Owner/OwnerDepartments";
import OwnerUsers from "./pages/Owner/OwnerUsers";
import OwnerReports from "./pages/Owner/OwnerReports";
import OwnerChat from "./pages/Owner/OwnerChat";
import OwnerSettings from "./pages/Owner/OwnerSettings";
import HousekeepingManager from "./pages/Owner/HousekeepingManager";

// خدمات أخرى
import Notifications from "./pages/Notifications";
import DashboardChat from "./pages/DashboardChat";
import LaundryNew from "./pages/LaundryNew";
import LaundryOrders from "./pages/LaundryOrders";
import LaundryInvoice from "./pages/LaundryInvoice";
import RoomServiceMenu from "./pages/RoomServiceMenu";
import HousekeepingBoard from "./pages/HousekeepingBoard";

export default function AppRouter() {
  const { user, loading } = useAuth();
  if (loading) return <div>جاري التحقق من الجلسة...</div>;

  return (
    <Routes>
      {/* الصفحة الرئيسية */}
      <Route
        path="/"
        element={
          user ? (
            <Navigate to={getLandingPath(user.role)} replace />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
      <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />

      {/* عامة */}
      <Route path="/login" element={user ? <Navigate to={getLandingPath(user.role)} replace /> : <Login />} />
      <Route path="/create-user" element={<CreateUser />} />
      <Route path="/setup-owner" element={<SetupOwner />} />
      <Route path="/unauthorized" element={<Unauthorized />} />

      {/* الضيف */}
      <Route path="/guest/home" element={<ProtectedRoute><GuestHome /></ProtectedRoute>} />
      <Route path="/guest/requests" element={<ProtectedRoute><GuestRequests /></ProtectedRoute>} />
      <Route path="/guest/housekeeping" element={<ProtectedRoute><GuestHousekeeping /></ProtectedRoute>} />
      <Route path="/guest/maintenance" element={<ProtectedRoute><GuestMaintenance /></ProtectedRoute>} />

      {/* الموظف والمشرف */}
      <Route path="/employee" element={<ProtectedRoute><EmployeeDashboard /></ProtectedRoute>} />
      <Route path="/supervisor" element={<ProtectedRoute><SupervisorDashboard /></ProtectedRoute>} />
      <Route path="/change-password" element={<ChangePassword />} />
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />

      {/* تخطيط المالك */}
      <Route path="/owner/*" element={
        <ProtectedRoute requiredPerm={PERMS.USERS_MANAGE}>
          <OwnerLayout />
        </ProtectedRoute>
      }>
        <Route index element={<OwnerHome />} />
        <Route path="dashboard" element={<OwnerHome />} />
        <Route path="departments" element={<OwnerDepartments />} />
        <Route path="users" element={<OwnerUsers />} />
        <Route path="reports" element={<OwnerReports />} />
        <Route path="support" element={<OwnerChat />} />
        <Route path="settings" element={<OwnerSettings />} />
        <Route path="housekeeping" element={<HousekeepingManager />} />
      </Route>

      {/* باقي الخدمات */}
      <Route path="/laundry/new" element={<ProtectedRoute requiredPerm={PERMS.LAUNDRY_MANAGE}><LaundryNew /></ProtectedRoute>} />
      <Route path="/laundry/orders" element={<ProtectedRoute requiredPerm={PERMS.LAUNDRY_VIEW}><LaundryOrders /></ProtectedRoute>} />
      <Route path="/laundry/invoice/:id" element={<ProtectedRoute requiredPerm={PERMS.LAUNDRY_VIEW}><LaundryInvoice /></ProtectedRoute>} />
      <Route path="/room-service/menu" element={<ProtectedRoute requiredPerm={PERMS.KITCHEN_VIEW}><RoomServiceMenu /></ProtectedRoute>} />
      <Route path="/housekeeping" element={<ProtectedRoute requiredPerm={PERMS.HK_VIEW}><HousekeepingBoard /></ProtectedRoute>} />

      {/* Notifications and Chat */}
      <Route path="/notifications" element={<ProtectedRoute requiredPerm={PERMS.NOTIFICATIONS_VIEW}><Notifications /></ProtectedRoute>} />
      <Route path="/chat" element={<ProtectedRoute requiredPerm={PERMS.CHAT_VIEW}><DashboardChat /></ProtectedRoute>} />

      {/* افتراضي لأي مسار غير معروف */}
      <Route path="*" element={<Navigate to={user ? "/dashboard" : "/login"} replace />} />
    </Routes>
  );
}

/** حساب صلاحيات المستخدم */
export function computeEffectivePerms(user: WavesUser): Perm[] {
  const permsSet = new Set<Perm>();
  const rolePerms = ROLE_PERMISSIONS[user.role] || [];
  rolePerms.forEach((p) => permsSet.add(p));
  if (user.dept) {
    const deptPerms = DEPT_PERMISSIONS[user.dept] || [];
    deptPerms.forEach((p) => permsSet.add(p));
  }
  if (user.perms) {
    user.perms.forEach((p) => permsSet.add(p));
  }
  return Array.from(permsSet);
}
