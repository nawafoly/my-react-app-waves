// src/context/AuthContext.tsx
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { WavesUser } from "../services/AuthService";

type AuthState = {
  user: WavesUser | null;
  loading: boolean;
  login: (u: WavesUser) => void;
  logout: () => void;
};

const AuthContext = createContext<AuthState>({
  user: null,
  loading: true,
  login: () => {},
  logout: () => {},
});

const LS_SESSION_KEY = "waves_session";
const LS_USERS_KEY = "waves_users";

export const AuthProvider: React.FC<React.PropsWithChildren> = ({ children }) => {
  const [user, setUser] = useState<WavesUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // استرجاع الجلسة عند بدء التشغيل
    try {
      const rawSess = localStorage.getItem(LS_SESSION_KEY);
      const rawUsers = localStorage.getItem(LS_USERS_KEY);
      if (rawSess && rawUsers) {
        const session = JSON.parse(rawSess) as { userId: string; at: number };
        const users = JSON.parse(rawUsers) as WavesUser[];
        const u = users.find((x) => x.id === session.userId) || null;
        setUser(u);
      } 
    } catch {
      // تجاهل أي JSON فاسد
    } finally {
      setLoading(false);
    }
  }, []);

  const login = (u: WavesUser) => {
    setUser(u);
    localStorage.setItem(LS_SESSION_KEY, JSON.stringify({ userId: u.id, at: Date.now() }));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(LS_SESSION_KEY);
  };

  const value = useMemo<AuthState>(() => ({ user, loading, login, logout }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export function useAuth() {
  return useContext(AuthContext);
}
