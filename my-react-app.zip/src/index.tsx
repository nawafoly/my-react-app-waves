import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";

const savedTheme = localStorage.getItem("theme") || "light";
document.documentElement.setAttribute("data-theme", savedTheme);

// Temporary ErrorBoundary to surface runtime errors
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { error: Error | null }> {
  constructor(props: any) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  componentDidCatch(error: Error, info: any) {
    console.error("Runtime error:", error, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 24, color: "#b91c1c", background: "#fee2e2", fontFamily: "monospace" }}>
          <h2>Application Error</h2>
          <pre>{String(this.state.error.message || this.state.error)}</pre>
          <p>Check console for stack trace.</p>
        </div>
      );
    }
    return this.props.children as any;
  }
}

import "./index.css";
import "./styles/Chat.css";
import "./styles/_tokens.css"; // تأكد من إضافته هنا

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </BrowserRouter>
  </React.StrictMode>
);
